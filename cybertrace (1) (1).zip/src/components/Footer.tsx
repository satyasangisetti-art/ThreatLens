import React from 'react';
import { Shield, Lock, Terminal, ExternalLink, Heart, AlertOctagon, Mail, Phone } from 'lucide-react';

export const Footer: React.FC<{ onNavigate: (page: string) => void }> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#03070f] border-t border-cyan-500/15 pt-16 pb-12 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-cyan-500/5 blur-3xl pointer-events-none rounded-full" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40">
                <Shield className="w-5 h-5 text-cyan-400" />
              </div>
              <span className="font-tech text-2xl font-bold tracking-wider text-white">
                CYBER<span className="text-cyan-400">TRACE</span>
              </span>
            </div>
            <p className="text-sm text-slate-400 max-w-sm leading-relaxed">
              AI-powered cybersecurity incident response platform. Defending individuals and enterprise security operations against advanced phishing, synthetic media manipulation, and online financial fraud.
            </p>
            <div className="flex items-center gap-4 text-xs font-mono-code text-cyan-400/80 pt-2">
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-cyan-500/20">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                SOC CORE: ONLINE
              </span>
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-purple-500/20 text-purple-300">
                GEMINI 3.8 FLASH ACTIVE
              </span>
            </div>
          </div>

          {/* Platform Capabilities */}
          <div>
            <h4 className="text-sm font-semibold text-white tracking-wider uppercase font-mono-code mb-4">
              Capabilities
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('features')} className="hover:text-cyan-400 transition-colors">
                  AI Phishing Engine
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('features')} className="hover:text-cyan-400 transition-colors">
                  AI Threat Intelligence
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('features')} className="hover:text-cyan-400 transition-colors">
                  Incident Management (SOC)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('features')} className="hover:text-cyan-400 transition-colors">
                  SHA-256 Evidence Vault
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('features')} className="hover:text-cyan-400 transition-colors">
                  Cybercrime Reporting
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Access */}
          <div>
            <h4 className="text-sm font-semibold text-white tracking-wider uppercase font-mono-code mb-4">
              Resources
            </h4>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('how-it-works')} className="hover:text-cyan-400 transition-colors">
                  How It Works
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-cyan-400 transition-colors">
                  Threat Architecture
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-cyan-400 transition-colors">
                  Emergency SOC Contact
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('login')} className="hover:text-cyan-400 transition-colors">
                  Analyst Login
                </button>
              </li>
              <li>
                <span className="text-xs text-slate-500">ISO 27001 / NIST CSF Aligned</span>
              </li>
            </ul>
          </div>

          {/* Emergency & Official Disclaimer */}
          <div>
            <h4 className="text-sm font-semibold text-white tracking-wider uppercase font-mono-code mb-4 flex items-center gap-1.5 text-amber-400">
              <AlertOctagon className="w-4 h-4" />
              Emergency Notice
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              CyberTrace is a technical triage and digital evidence preservation system. For active extortion or immediate physical threats, contact your local jurisdiction:
            </p>
            <div className="text-xs space-y-1.5 font-mono-code text-slate-300">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">US:</span> IC3.gov / CISA
              </div>
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">IN:</span> cybercrime.gov.in (1930)
              </div>
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">EU:</span> Europol EC3
              </div>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer & Bottom */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {new Date().getFullYear()} CYBERTRACE Systems. All rights reserved. Built for intelligent enterprise threat mitigation.
          </p>
          <div className="flex items-center gap-6">
            <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-slate-400 cursor-pointer">Terms of Service</span>
            <span className="hover:text-slate-400 cursor-pointer">Security Standards</span>
            <span className="hover:text-slate-400 cursor-pointer">Chain of Custody Legal Notes</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
