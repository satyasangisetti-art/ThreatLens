import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { api } from '../lib/api';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password?: string) => Promise<void>;
  register: (email: string, password?: string, name?: string, organization?: string) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  demoLogin: (role?: 'analyst' | 'admin') => Promise<void>;
  isSupabaseMode: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_STORAGE_USER_KEY = 'cybertrace_auth_user';
const LOCAL_STORAGE_SESSION_KEY = 'cybertrace_auth_token';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Initialize session on mount
  useEffect(() => {
    async function initSession() {
      try {
        if (isSupabaseConfigured && supabase) {
          const { data } = await supabase.auth.getSession();
          if (data.session?.user) {
            setUser({
              id: data.session.user.id,
              email: data.session.user.email || 'analyst@cybertrace.io',
              name: data.session.user.user_metadata?.name || 'Authorized Analyst',
              role: 'SOC Analyst',
              organization: data.session.user.user_metadata?.organization || 'CyberTrace Core SOC',
              twoFactorEnabled: true,
              createdAt: data.session.user.created_at || new Date().toISOString(),
            });
            setIsLoading(false);
            return;
          }
        }

        // Check local storage
        const savedUser = localStorage.getItem(LOCAL_STORAGE_USER_KEY);
        if (savedUser) {
          setUser(JSON.parse(savedUser));
        }
      } catch (err) {
        console.warn('Failed to restore auth session:', err);
      } finally {
        setIsLoading(false);
      }
    }

    initSession();
  }, []);

  const login = async (email: string, password?: string) => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured && supabase && password) {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        if (data.user) {
          const u: User = {
            id: data.user.id,
            email: data.user.email || email,
            name: data.user.user_metadata?.name || email.split('@')[0],
            role: 'SOC Analyst',
            organization: data.user.user_metadata?.organization || 'CyberTrace Enterprise SOC',
            twoFactorEnabled: true,
            createdAt: data.user.created_at || new Date().toISOString(),
          };
          setUser(u);
          localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(u));
          return;
        }
      }

      // Backend API login
      const res = await api.login(email, password);
      setUser(res.user);
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(res.user));
      if (res.session?.token) {
        localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, res.session.token);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (email: string, password?: string, name?: string, organization?: string) => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured && supabase && password) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: { name: name || email.split('@')[0], organization: organization || 'CyberTrace Guard Network' },
          },
        });
        if (error) throw error;
        if (data.user) {
          const u: User = {
            id: data.user.id,
            email: data.user.email || email,
            name: name || email.split('@')[0],
            role: 'SOC Analyst',
            organization: organization || 'CyberTrace Guard Network',
            twoFactorEnabled: false,
            createdAt: data.user.created_at || new Date().toISOString(),
          };
          setUser(u);
          localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(u));
          return;
        }
      }

      const res = await api.register({
        email,
        name: name || email.split('@')[0],
        organization: organization || 'CyberTrace Guard Network',
      });
      setUser(res.user);
      localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(res.user));
      if (res.session?.token) {
        localStorage.setItem(LOCAL_STORAGE_SESSION_KEY, res.session.token);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured && supabase) {
        await supabase.auth.signOut();
      }
      await api.logout().catch(() => {});
      setUser(null);
      localStorage.removeItem(LOCAL_STORAGE_USER_KEY);
      localStorage.removeItem(LOCAL_STORAGE_SESSION_KEY);
    } finally {
      setIsLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    if (isSupabaseConfigured && supabase) {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) throw error;
    }
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    setUser(updated);
    localStorage.setItem(LOCAL_STORAGE_USER_KEY, JSON.stringify(updated));
  };

  const demoLogin = async (role: 'analyst' | 'admin' = 'analyst') => {
    const demoEmail = role === 'admin' ? 'muthangisriharsha@gmail.com' : 'analyst@cybertrace.io';
    await login(demoEmail, 'CyberTrace@Demo2026!');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        register,
        logout,
        resetPassword,
        updateProfile,
        demoLogin,
        isSupabaseMode: isSupabaseConfigured,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
