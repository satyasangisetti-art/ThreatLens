import React, { useState, useEffect } from 'react';
import {
  Shield,
  LayoutDashboard,
  ShieldAlert,
  Cpu,
  MailWarning,
  Eye,
  FileCheck2,
  FileText,
  Activity,
  Settings,
  LogOut,
  Bell,
  Search,
  Menu,
  X,
  ChevronRight,
  ExternalLink,
  PlusCircle,
  Clock,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

interface DashboardLayoutProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  onOpenQuickScan?: () => void;
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({
  currentTab,
  onSelectTab,
  onOpenQuickScan,
  children,
}) => {
  const { user, logout } = useAuth();
  const { info } = useToast();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState<string>('');
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Live SOC UTC Clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC'
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'incidents', label: 'Incident Management', icon: ShieldAlert, badge: 'Live' },
    { id: 'analyzer', label: 'Threat Analyzer', icon: Cpu, badge: 'AI' },
    { id: 'phishing', label: 'Phishing Detection', icon: MailWarning },
    { id: 'evidence', label: 'Evidence Vault', icon: FileCheck2 },
    { id: 'reports', label: 'Cybercrime Reports', icon: FileText },
    { id: 'logs', label: 'Activity Logs', icon: Activity },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const recentNotifications = [
    {
      id: 'n-1',
      title: 'High Risk Phishing Lure Blocked',
      time: '4m ago',
      category: 'Phishing',
      severity: 'Critical',
    },
    {
      id: 'n-2',
      title: 'PowerShell Memory Beacon Quarantined',
      time: '32m ago',
      category: 'Unauthorized Access',
      severity: 'High',
    },
    {
      id: 'n-3',
      title: 'Evidence SHA-256 Checksum Verified',
      time: '1h ago',
      category: 'Vault',
      severity: 'Info',
    },
    {
      id: 'n-4',
      title: 'Cybercrime Complaint Reference CT-CR-2026-0492 Logged',
      time: '3h ago',
      category: 'Fraud',
      severity: 'Medium',
    },
  ];

  const handleGlobalSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    info(`Searching SOC telemetry for: "${searchQuery}"`);
    // Route to incidents tab with pre-fill if helpful
    onSelectTab('incidents');
  };

  return (
    <div className="min-h-screen bg-[#040812] text-slate-100 flex flex-col font-sans">
      {/* Top SOC Status Banner */}
      <div className="bg-[#02050b] border-b border-cyan-500/20 px-4 py-1.5 text-[11px] font-mono-code flex items-center justify-between text-slate-400">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-semibold">DEFCON 4: NOMINAL</span>
          </div>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="hidden sm:inline text-cyan-300">CORE NODE: APAC-EDGE-01</span>
          <span className="hidden md:inline text-slate-600">|</span>
          <span className="hidden md:inline text-purple-300">AI INFERENCE: GEMINI 3.8 FLASH</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-cyan-400 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {currentTime || 'SYNCHRONIZING...'}
          </span>
        </div>
      </div>

      {/* Main Top Header */}
      <header className="h-16 bg-[#070e1c]/90 backdrop-blur-md border-b border-cyan-500/15 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-3">
          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Logo in Header */}
          <div
            onClick={() => onSelectTab('overview')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500/30 to-blue-600/40 border border-cyan-500/40 flex items-center justify-center group-hover:border-cyan-400 transition-all">
              <Shield className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="hidden sm:block">
              <span className="font-tech text-lg font-bold tracking-wider text-white">
                CYBER<span className="text-cyan-400">TRACE</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono-code ml-1.5 uppercase">SOC Core</span>
            </div>
          </div>
        </div>

        {/* Center Search Bar */}
        <div className="flex-1 max-w-md mx-4 hidden md:block">
          <form onSubmit={handleGlobalSearch} className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search incidents, IP, hash, CVE, URL..."
              className="w-full pl-9 pr-12 py-1.5 text-xs bg-slate-900/90 border border-slate-700/80 focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 rounded-lg text-slate-200 placeholder-slate-500 font-mono-code transition-all"
            />
            <kbd className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] bg-slate-800 border border-slate-700 text-slate-400 px-1.5 py-0.5 rounded">
              ↵
            </kbd>
          </form>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Quick Threat Scan Button */}
          <button
            onClick={() => onSelectTab('analyzer')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-all shadow-[0_0_15px_rgba(6,182,212,0.15)] cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            Quick AI Scan
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="relative p-2 rounded-lg bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            </button>

            {notificationsOpen && (
              <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-[#0a1222] border border-cyan-500/30 rounded-xl shadow-2xl z-50 overflow-hidden animate-in fade-in-50">
                <div className="p-3 bg-[#0d182b] border-b border-cyan-500/20 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-cyan-400" />
                    <span className="font-semibold text-xs tracking-wide text-white uppercase font-mono-code">
                      SOC Real-time Alerts
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-red-500/20 text-red-300 font-mono-code border border-red-500/30">
                    4 Active
                  </span>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/80">
                  {recentNotifications.map(n => (
                    <div
                      key={n.id}
                      onClick={() => {
                        setNotificationsOpen(false);
                        onSelectTab('incidents');
                      }}
                      className="p-3 hover:bg-cyan-950/20 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-200">{n.title}</span>
                        <span className="text-[10px] text-slate-500 font-mono-code">{n.time}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] font-mono-code">
                        <span className="text-cyan-400">{n.category}</span>
                        <span className="text-slate-600">•</span>
                        <span
                          className={`font-semibold ${
                            n.severity === 'Critical'
                              ? 'text-red-400'
                              : n.severity === 'High'
                              ? 'text-amber-400'
                              : 'text-cyan-400'
                          }`}
                        >
                          {n.severity}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-2.5 bg-[#070e1a] text-center border-t border-slate-800">
                  <button
                    onClick={() => {
                      setNotificationsOpen(false);
                      onSelectTab('logs');
                    }}
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 font-mono-code"
                  >
                    View All Activity Logs →
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* User Profile Badge */}
          <div
            onClick={() => onSelectTab('settings')}
            className="flex items-center gap-2.5 pl-2 py-1 pr-3 rounded-lg bg-slate-900/60 border border-slate-800/80 hover:border-cyan-500/40 transition-colors cursor-pointer"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center text-xs font-bold text-white shadow-inner">
              {user?.name ? user.name.charAt(0).toUpperCase() : 'A'}
            </div>
            <div className="hidden lg:block text-left">
              <p className="text-xs font-medium text-slate-200 leading-tight">
                {user?.name || 'Analyst'}
              </p>
              <p className="text-[10px] text-cyan-400 font-mono-code leading-tight">
                {user?.role || 'SOC Analyst'}
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Body with Sidebar and Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Desktop Sidebar */}
        <aside
          className={`hidden md:flex flex-col bg-[#050b16] border-r border-cyan-500/15 transition-all duration-300 shrink-0 ${
            sidebarCollapsed ? 'w-20' : 'w-64'
          }`}
        >
          {/* Navigation Links */}
          <div className="flex-1 py-4 px-3 space-y-1.5 overflow-y-auto">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  title={item.label}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all group cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500/15 to-blue-600/10 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(6,182,212,0.15)] font-semibold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                      isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-cyan-300'
                    }`}
                  />
                  {!sidebarCollapsed && (
                    <span className="flex-1 text-left truncate">{item.label}</span>
                  )}
                  {!sidebarCollapsed && item.badge && (
                    <span
                      className={`text-[9px] font-mono-code px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                        item.badge === 'AI'
                          ? 'bg-purple-900/60 text-purple-300 border border-purple-500/30'
                          : item.badge === 'Live'
                          ? 'bg-red-900/60 text-red-300 border border-red-500/30 animate-pulse'
                          : 'bg-cyan-950 text-cyan-300 border border-cyan-500/30'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Sidebar Bottom Controls */}
          <div className="p-3 border-t border-slate-800/80 space-y-2">
            <button
              onClick={() => logout()}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium text-red-400/80 hover:text-red-300 hover:bg-red-950/20 border border-transparent hover:border-red-500/30 transition-all cursor-pointer"
            >
              <LogOut className="w-4 h-4 shrink-0" />
              {!sidebarCollapsed && <span>Sign Out SOC</span>}
            </button>

            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="w-full flex items-center justify-center p-1.5 text-slate-500 hover:text-slate-300 hover:bg-slate-900/60 rounded text-xs transition-colors"
            >
              {sidebarCollapsed ? 'Expand »' : '« Collapse'}
            </button>
          </div>
        </aside>

        {/* Mobile Sidebar Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            <div
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/70 backdrop-blur-sm"
            />
            <div className="relative w-72 bg-[#060c18] border-r border-cyan-500/20 flex flex-col p-4 z-10">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Shield className="w-6 h-6 text-cyan-400" />
                  <span className="font-tech text-lg font-bold text-white">CYBERTRACE</span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 py-4 space-y-1.5 overflow-y-auto">
                {navItems.map(item => {
                  const Icon = item.icon;
                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectTab(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                        isActive
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-semibold'
                          : 'text-slate-300 hover:bg-slate-800/60'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>

              <div className="pt-3 border-t border-slate-800">
                <button
                  onClick={() => logout()}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium text-red-400 hover:bg-red-950/20"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic Page Content Viewport */}
        <main className="flex-1 overflow-y-auto bg-[#040812] cyber-grid relative">
          <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 pb-20">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};
