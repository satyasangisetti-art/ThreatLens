import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ToastProvider, useToast } from './contexts/ToastContext';
import { LandingPage } from './pages/LandingPage';
import { AuthPage } from './pages/AuthPage';
import { DashboardLayout } from './layouts/DashboardLayout';
import { DashboardOverview } from './pages/DashboardOverview';
import { IncidentManagement } from './pages/IncidentManagement';
import { ThreatAnalyzer } from './pages/ThreatAnalyzer';
import { PhishingDetection } from './pages/PhishingDetection';
import { EvidenceVault } from './pages/EvidenceVault';
import { CybercrimeReports } from './pages/CybercrimeReports';
import { ActivityLogs } from './pages/ActivityLogs';
import { SettingsPage } from './pages/SettingsPage';
import { Shield } from 'lucide-react';

function AppContent() {
  const { user, isLoading } = useAuth();
  const { info, success } = useToast();

  // Navigation state
  // Public routes: 'home', 'login', 'register'
  // Protected tabs: 'overview', 'incidents', 'analyzer', 'phishing', 'image-forensics', 'evidence', 'reports', 'logs', 'settings'
  const [currentRoute, setCurrentRoute] = useState<string>('home');
  const [dashboardTab, setDashboardTab] = useState<string>('overview');

  // Loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#040812] flex flex-col items-center justify-center p-4">
        <div className="relative flex items-center justify-center mb-4">
          <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center animate-pulse">
            <Shield className="w-8 h-8 text-cyan-400" />
          </div>
          <div className="absolute inset-0 rounded-2xl border border-cyan-400/50 animate-ping" />
        </div>
        <div className="font-tech text-lg font-bold tracking-wider text-white">
          CYBER<span className="text-cyan-400">TRACE</span>
        </div>
        <p className="text-xs font-mono-code text-slate-400 mt-2">
          Initializing Threat Intelligence Telemetry...
        </p>
      </div>
    );
  }

  // Handle navigation
  const handleNavigate = (page: string) => {
    if (page === 'login' || page === 'register') {
      setCurrentRoute(page);
    } else if (page === 'dashboard') {
      if (!user) {
        info('Authentication Required', 'Please log in to access the CyberTrace SOC Console.');
        setCurrentRoute('login');
      } else {
        setCurrentRoute('dashboard');
        setDashboardTab('overview');
      }
    } else if (page === 'home' || page === 'features' || page === 'how-it-works' || page === 'about' || page === 'contact') {
      setCurrentRoute('home');
    } else if (page === 'analyzer' || page === 'phishing' || page === 'incidents' || page === 'evidence') {
      if (!user) {
        info('SOC Login Required', 'Authentication required to inspect live vectors.');
        setCurrentRoute('login');
      } else {
        setCurrentRoute('dashboard');
        setDashboardTab(page);
      }
    } else {
      setCurrentRoute(page);
    }
  };

  // Switch tabs in dashboard
  const handleSelectTab = (tab: string) => {
    setDashboardTab(tab);
  };

  // If user navigated to login or register
  if (currentRoute === 'login' || currentRoute === 'register') {
    return (
      <AuthPage
        initialMode={currentRoute === 'register' ? 'register' : 'login'}
        onNavigate={handleNavigate}
      />
    );
  }

  // If user is accessing protected dashboard
  if (currentRoute === 'dashboard' || user && currentRoute !== 'home') {
    // If user somehow lost session, bounce to login
    if (!user) {
      return <AuthPage initialMode="login" onNavigate={handleNavigate} />;
    }

    return (
      <DashboardLayout
        currentTab={dashboardTab}
        onSelectTab={handleSelectTab}
        onOpenQuickScan={() => handleSelectTab('analyzer')}
      >
        {dashboardTab === 'overview' && (
          <DashboardOverview onNavigateTab={handleSelectTab} />
        )}

        {dashboardTab === 'incidents' && (
          <IncidentManagement />
        )}

        {dashboardTab === 'analyzer' && (
          <ThreatAnalyzer
            onEscalateToIncident={() => {
              handleSelectTab('incidents');
            }}
            onPreserveAsEvidence={() => {
              handleSelectTab('evidence');
            }}
          />
        )}

        {dashboardTab === 'phishing' && (
          <PhishingDetection />
        )}

        {dashboardTab === 'evidence' && (
          <EvidenceVault />
        )}

        {dashboardTab === 'reports' && (
          <CybercrimeReports />
        )}

        {dashboardTab === 'logs' && (
          <ActivityLogs />
        )}

        {dashboardTab === 'settings' && (
          <SettingsPage />
        )}
      </DashboardLayout>
    );
  }

  // Otherwise, default to Landing Page
  return <LandingPage onNavigate={handleNavigate} />;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </AuthProvider>
  );
}
