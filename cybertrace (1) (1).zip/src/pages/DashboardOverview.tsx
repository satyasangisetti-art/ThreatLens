import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  FileCheck2,
  Cpu,
  MailWarning,
  Activity,
  ArrowUpRight,
  TrendingUp,
  ExternalLink,
  ChevronRight,
  RefreshCw,
  Clock,
  Sparkles,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  Legend,
} from 'recharts';
import { api } from '../lib/api';
import { Incident, ActivityLog, DashboardMetrics } from '../types';
import { useToast } from '../contexts/ToastContext';

interface DashboardOverviewProps {
  onNavigateTab: (tab: string) => void;
  onSelectIncident?: (incident: Incident) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  onNavigateTab,
  onSelectIncident,
}) => {
  const { error: toastError, info } = useToast();
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    totalIncidents: 4,
    activeThreats: 2,
    resolvedIncidents: 2,
    criticalAlerts: 1,
    suspiciousUrlsAnalyzed: 146,
    totalEvidenceStored: 3,
    socHealthScore: 94.8,
  });

  const [severityData, setSeverityData] = useState<Array<{ name: string; value: number; color: string }>>([
    { name: 'Critical', value: 1, color: '#ef4444' },
    { name: 'High', value: 2, color: '#f97316' },
    { name: 'Medium', value: 1, color: '#eab308' },
    { name: 'Low', value: 0, color: '#06b6d4' },
  ]);

  const [trendData, setTrendData] = useState<any[]>([
    { day: 'Mon', incidents: 4, blockedThreats: 18, resolved: 3 },
    { day: 'Tue', incidents: 7, blockedThreats: 24, resolved: 5 },
    { day: 'Wed', incidents: 5, blockedThreats: 31, resolved: 6 },
    { day: 'Thu', incidents: 9, blockedThreats: 42, resolved: 8 },
    { day: 'Fri', incidents: 12, blockedThreats: 55, resolved: 10 },
    { day: 'Sat', incidents: 6, blockedThreats: 29, resolved: 7 },
    { day: 'Sun', incidents: 8, blockedThreats: 38, resolved: 6 },
  ]);

  const [categoryBreakdown, setCategoryBreakdown] = useState<Array<{ category: string; count: number }>>([
    { category: 'Phishing', count: 2 },
    { category: 'Unauthorized Access', count: 1 },
    { category: 'Financial Fraud', count: 1 },
    { category: 'DDoS Attack', count: 1 },
  ]);

  const [recentIncidents, setRecentIncidents] = useState<Incident[]>([]);
  const [recentActivity, setRecentActivity] = useState<ActivityLog[]>([]);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const res = await api.getDashboardStats();
      if (res.metrics) setMetrics(res.metrics);
      if (res.severityDistribution) setSeverityData(res.severityDistribution);
      if (res.trendData) setTrendData(res.trendData);
      if (res.categoryBreakdown) setCategoryBreakdown(res.categoryBreakdown);
      if (res.recentIncidents) setRecentIncidents(res.recentIncidents);
      if (res.recentActivity) setRecentActivity(res.recentActivity);
    } catch (err: any) {
      console.warn('Using local telemetry state:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const statCards = [
    {
      title: 'Total Incidents',
      value: metrics.totalIncidents,
      icon: ShieldAlert,
      change: '+2 today',
      color: 'cyan',
      borderColor: 'border-cyan-500/30',
      bgColor: 'from-cyan-950/30 to-slate-900/40',
      textColor: 'text-cyan-400',
    },
    {
      title: 'Active Threats',
      value: metrics.activeThreats,
      icon: AlertTriangle,
      change: 'Requiring Triage',
      color: 'amber',
      borderColor: 'border-amber-500/30',
      bgColor: 'from-amber-950/30 to-slate-900/40',
      textColor: 'text-amber-400',
    },
    {
      title: 'Resolved Incidents',
      value: metrics.resolvedIncidents,
      icon: ShieldCheck,
      change: '100% SLA Met',
      color: 'emerald',
      borderColor: 'border-emerald-500/30',
      bgColor: 'from-emerald-950/30 to-slate-900/40',
      textColor: 'text-emerald-400',
    },
    {
      title: 'Critical Alerts',
      value: metrics.criticalAlerts,
      icon: ShieldAlert,
      change: 'Elevated Urgency',
      color: 'red',
      borderColor: 'border-red-500/30',
      bgColor: 'from-red-950/30 to-slate-900/40',
      textColor: 'text-red-400',
    },
    {
      title: 'Suspicious URLs Analyzed',
      value: metrics.suspiciousUrlsAnalyzed,
      icon: MailWarning,
      change: 'Gemini Deep Scanned',
      color: 'purple',
      borderColor: 'border-purple-500/30',
      bgColor: 'from-purple-950/30 to-slate-900/40',
      textColor: 'text-purple-400',
    },
    {
      title: 'Evidence Files Stored',
      value: metrics.totalEvidenceStored,
      icon: FileCheck2,
      change: 'SHA-256 Verified',
      color: 'blue',
      borderColor: 'border-blue-500/30',
      bgColor: 'from-blue-950/30 to-slate-900/40',
      textColor: 'text-blue-400',
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Header & Triage Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
              SOC Command Center
            </h1>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold uppercase">
              LIVE TELEMETRY
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono-code mt-1">
            Real-time Threat Monitoring & Cryptographic Incident Triage
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              fetchStats();
              info('Telemetry refreshed');
            }}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs transition-colors cursor-pointer flex items-center gap-1.5 font-mono-code"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh</span>
          </button>

          <button
            onClick={() => onNavigateTab('incidents')}
            className="px-3.5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_15px_rgba(6,182,212,0.3)] cursor-pointer flex items-center gap-1.5"
          >
            <span>+ New Incident</span>
          </button>
        </div>
      </div>

      {/* 6 Metric Statistics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {statCards.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div
              key={idx}
              className={`p-4 rounded-xl bg-gradient-to-b ${stat.bgColor} border ${stat.borderColor} shadow-lg backdrop-blur-sm transition-all hover:scale-[1.02]`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono-code uppercase tracking-wider text-slate-400 truncate">
                  {stat.title}
                </span>
                <Icon className={`w-4 h-4 ${stat.textColor}`} />
              </div>
              <div className="font-tech text-2xl sm:text-3xl font-bold text-white mb-1">
                {stat.value}
              </div>
              <div className={`text-[10px] font-mono-code ${stat.textColor} flex items-center gap-1 truncate`}>
                <span>{stat.change}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 7-Day Incident Trend Chart */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <h3 className="font-tech text-base font-bold text-white uppercase tracking-wider">
                7-Day Threat Vector & Resolution Trend
              </h3>
            </div>
            <div className="flex items-center gap-4 text-[10px] font-mono-code">
              <span className="flex items-center gap-1.5 text-cyan-400">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                Blocked Threats
              </span>
              <span className="flex items-center gap-1.5 text-purple-400">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-400" />
                Incidents Logged
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="cyanGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="purpleGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#a855f7" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#a855f7" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="day" stroke="#64748b" fontSize={11} fontFamily="monospace" />
                <YAxis stroke="#64748b" fontSize={11} fontFamily="monospace" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a1424',
                    borderColor: '#06b6d4',
                    borderRadius: '8px',
                    fontSize: '11px',
                    fontFamily: 'monospace',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="blockedThreats"
                  name="Blocked Threats"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#cyanGradient)"
                />
                <Area
                  type="monotone"
                  dataKey="incidents"
                  name="Incidents"
                  stroke="#a855f7"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#purpleGradient)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Severity Distribution Donut */}
        <div className="p-5 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <h3 className="font-tech text-base font-bold text-white uppercase tracking-wider">
                Threat Severity
              </h3>
            </div>
            <span className="text-[10px] font-mono-code text-slate-400">Current Distribution</span>
          </div>

          <div className="h-48 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={severityData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={75}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {severityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0a1424',
                    borderColor: '#38bdf8',
                    borderRadius: '8px',
                    fontSize: '11px',
                    fontFamily: 'monospace',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-xs font-mono-code">
            {severityData.map((item, i) => (
              <div key={i} className="flex items-center justify-between p-1.5 rounded bg-slate-900/60">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-300">{item.name}</span>
                </div>
                <span className="font-bold text-white">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lower Row: Recent Security Incidents & Live SOC Activity Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recent Incidents Table */}
        <div className="lg:col-span-8 p-5 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-cyan-400" />
              <h3 className="font-tech text-base font-bold text-white uppercase tracking-wider">
                Recent Security Incidents
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('incidents')}
              className="text-xs font-mono-code text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
            >
              All Incidents ({metrics.totalIncidents}) →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono-code">
              <thead>
                <tr className="text-slate-500 border-b border-slate-800">
                  <th className="pb-2.5">ID / TITLE</th>
                  <th className="pb-2.5">CATEGORY</th>
                  <th className="pb-2.5">SEVERITY</th>
                  <th className="pb-2.5">STATUS</th>
                  <th className="pb-2.5 text-right">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {recentIncidents.map(inc => {
                  let sevColor = 'text-cyan-400 bg-cyan-950/60 border-cyan-500/30';
                  if (inc.severity === 'Critical') sevColor = 'text-red-400 bg-red-950/60 border-red-500/30';
                  else if (inc.severity === 'High') sevColor = 'text-amber-400 bg-amber-950/60 border-amber-500/30';
                  else if (inc.severity === 'Medium') sevColor = 'text-yellow-400 bg-yellow-950/60 border-yellow-500/30';

                  let statusBadge = 'text-blue-400 bg-blue-950/60 border-blue-500/30';
                  if (inc.status === 'Resolved') statusBadge = 'text-emerald-400 bg-emerald-950/60 border-emerald-500/30';
                  else if (inc.status === 'Investigating') statusBadge = 'text-purple-400 bg-purple-950/60 border-purple-500/30 animate-pulse';

                  return (
                    <tr
                      key={inc.id}
                      onClick={() => onNavigateTab('incidents')}
                      className="hover:bg-cyan-950/10 transition-colors cursor-pointer"
                    >
                      <td className="py-3 pr-2">
                        <div className="font-semibold text-white truncate max-w-xs">{inc.title}</div>
                        <div className="text-[10px] text-cyan-400/80">{inc.incidentNumber} • {inc.assignedInvestigator}</div>
                      </td>
                      <td className="py-3 text-slate-300">{inc.category}</td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${sevColor}`}>
                          {inc.severity}
                        </span>
                      </td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${statusBadge}`}>
                          {inc.status}
                        </span>
                      </td>
                      <td className="py-3 text-right">
                        <button
                          onClick={e => {
                            e.stopPropagation();
                            onNavigateTab('incidents');
                          }}
                          className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 hover:border-cyan-400 text-cyan-300 text-[10px] transition-colors"
                        >
                          Triage
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Live System Activity Stream */}
        <div className="lg:col-span-4 p-5 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-purple-400" />
              <h3 className="font-tech text-base font-bold text-white uppercase tracking-wider">
                Live SOC Logs
              </h3>
            </div>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          </div>

          <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
            {recentActivity.map(log => {
              let tagColor = 'border-cyan-500/30 text-cyan-300 bg-cyan-950/30';
              if (log.severity === 'alert') tagColor = 'border-red-500/40 text-red-300 bg-red-950/40';
              else if (log.severity === 'warning') tagColor = 'border-amber-500/40 text-amber-300 bg-amber-950/40';
              else if (log.severity === 'success') tagColor = 'border-emerald-500/40 text-emerald-300 bg-emerald-950/40';

              return (
                <div
                  key={log.id}
                  className={`p-2.5 rounded-xl border ${tagColor} text-xs font-mono-code space-y-1`}
                >
                  <div className="flex items-center justify-between text-[10px] text-slate-400">
                    <span className="font-bold text-slate-200">{log.action}</span>
                    <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed line-clamp-2">
                    {log.details}
                  </p>
                  <div className="text-[9px] text-slate-500">
                    By: {log.user} • IP: {log.ipAddress}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-800">
            <button
              onClick={() => onNavigateTab('logs')}
              className="w-full py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-400 hover:text-cyan-300 text-xs font-mono-code text-center transition-colors"
            >
              Open Full SOC Audit Stream →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
