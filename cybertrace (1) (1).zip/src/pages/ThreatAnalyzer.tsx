import React, { useState } from 'react';
import {
  Cpu,
  Globe,
  Mail,
  MessageSquare,
  FileText,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Sparkles,
  CheckCircle2,
  Copy,
  Download,
  ArrowRight,
  Shield,
  HelpCircle,
  Clock,
  Terminal,
} from 'lucide-react';
import { api } from '../lib/api';
import { ThreatAnalysis } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

interface ThreatAnalyzerProps {
  onEscalateToIncident?: (title: string, description: string, category: string, severity: string) => void;
  onPreserveAsEvidence?: (filename: string, content: string) => void;
}

export const ThreatAnalyzer: React.FC<ThreatAnalyzerProps> = ({
  onEscalateToIncident,
  onPreserveAsEvidence,
}) => {
  const { user } = useAuth();
  const { success, error: toastError, info } = useToast();

  const [activeTab, setActiveTab] = useState<'url' | 'email' | 'sms' | 'whatsapp' | 'text'>('url');
  const [content, setContent] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<ThreatAnalysis | null>(null);

  // Quick preset samples for evaluator convenience
  const presets: Record<string, { label: string; text: string; tab: typeof activeTab }> = {
    m365Phish: {
      label: 'M365 Phishing Lure (URL)',
      tab: 'url',
      text: 'https://auth-secure-portal365-verify.com/login?session_redirect=corporate-sso-challenge',
    },
    wireFraud: {
      label: 'Urgent Wire Transfer (Email)',
      tab: 'email',
      text: `From: CEO Office <ceo-urgent@executive-office-internal.org>\nSubject: URGENT: Complete offshore vendor wire before 5 PM\n\nPlease process an urgent wire transfer of $48,200 to our supplier account immediately. Do not call my cell as I am in an emergency board meeting. Transfer receipt required within 1 hour.`,
    },
    bankSms: {
      label: 'Bank Account Suspension (SMS)',
      tab: 'sms',
      text: 'Chase Alert: Your debit card has been temporarily locked due to unusual debit. Verify your identity within 24 hours at http://192.168.4.11/chase-auth to avoid permanent card cancellation.',
    },
    safeDomain: {
      label: 'Legitimate Domain (URL)',
      tab: 'url',
      text: 'https://docs.github.com/en/actions/security-guides/security-hardening-for-github-actions',
    },
  };

  const handleApplyPreset = (key: string) => {
    const p = presets[key];
    setActiveTab(p.tab);
    setContent(p.text);
    info(`Loaded sample: ${p.label}`);
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    setAnalyzing(true);
    setAnalysisResult(null);

    try {
      const res = await api.analyzeThreat(content, activeTab === 'whatsapp' ? 'sms' : activeTab, user?.name);
      setAnalysisResult(res.result);
      if (res.result.riskScore >= 70) {
        success('Threat Vector Analyzed', `High risk anomaly identified: ${res.result.threatCategory}`);
      } else {
        success('Deep Scan Complete', `Content scored at ${res.result.riskScore}/100.`);
      }
    } catch (err: any) {
      toastError('Analysis Engine Failure', err.message);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleCopyReport = () => {
    if (!analysisResult) return;
    const textReport = `
CYBERTRACE THREAT INTELLIGENCE REPORT
ID: ${analysisResult.id}
Date: ${analysisResult.analyzedAt}
Risk Score: ${analysisResult.riskScore}/100 (${analysisResult.riskClassification})
Category: ${analysisResult.threatCategory}
Confidence: ${analysisResult.confidenceScore}%
Engine: ${analysisResult.engine}

INDICATORS:
${analysisResult.indicators.map(i => `• ${i}`).join('\n')}

ANALYSIS:
${analysisResult.explanation}

RECOMMENDED ACTIONS:
${analysisResult.recommendedActions.map(a => `[ ] ${a}`).join('\n')}
    `.trim();

    navigator.clipboard.writeText(textReport);
    success('Report Copied', 'Forensic summary copied to clipboard.');
  };

  const handleEscalate = () => {
    if (!analysisResult) return;
    const sev = analysisResult.riskScore >= 80 ? 'Critical' : analysisResult.riskScore >= 60 ? 'High' : 'Medium';
    if (onEscalateToIncident) {
      onEscalateToIncident(
        `Automated Escalate: ${analysisResult.threatCategory}`,
        `Suspected threat identified by CyberTrace AI Engine.\nRisk Score: ${analysisResult.riskScore}/100 (${analysisResult.riskClassification})\nIndicators:\n${analysisResult.indicators.join('\n')}\n\nContent:\n${analysisResult.inputContent}`,
        analysisResult.threatCategory.includes('Phishing') ? 'Phishing' : 'Financial Fraud',
        sev
      );
      success('Escalated to SOC Queue', 'New incident initialized in Incident Management.');
    } else {
      info('Navigate to Incident Management to view escalated case.');
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return { bg: 'bg-red-500', text: 'text-red-400', border: 'border-red-500/50', glow: 'glow-crimson' };
    if (score >= 60) return { bg: 'bg-amber-500', text: 'text-amber-400', border: 'border-amber-500/50', glow: '' };
    if (score >= 30) return { bg: 'bg-yellow-500', text: 'text-yellow-400', border: 'border-yellow-500/50', glow: '' };
    return { bg: 'bg-emerald-500', text: 'text-emerald-400', border: 'border-emerald-500/50', glow: 'glow-cyan' };
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
              AI Threat Analyzer
            </h1>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-purple-950/80 text-purple-300 border border-purple-500/40 font-bold uppercase flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-purple-400" />
              GEMINI 3.8 FLASH
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono-code mt-1">
            Multimodal Threat Forensics • Lexical Deconstruction • Heuristic Evaluation
          </p>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] font-mono-code text-slate-400">Sample Lures:</span>
          {Object.entries(presets).map(([k, p]) => (
            <button
              key={k}
              type="button"
              onClick={() => handleApplyPreset(k)}
              className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 hover:border-cyan-400 text-[10px] font-mono-code transition-colors cursor-pointer"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Analysis Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Input Panel */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4">
            {/* Input Type Tabs */}
            <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono-code">
              <button
                type="button"
                onClick={() => setActiveTab('url')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  activeTab === 'url' ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                URL
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('email')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  activeTab === 'email' ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                Email
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('sms')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  activeTab === 'sms' ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                SMS / Chat
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('text')}
                className={`flex-1 py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  activeTab === 'text' ? 'bg-cyan-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                Text
              </button>
            </div>

            {/* Input Form */}
            <form onSubmit={handleAnalyze} className="space-y-4">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>
                    {activeTab === 'url'
                      ? 'Target Suspicious URL / Domain'
                      : activeTab === 'email'
                      ? 'Raw Email Headers & Body'
                      : activeTab === 'sms'
                      ? 'SMS or WhatsApp Message Payload'
                      : 'Suspicious Code, Log, or Raw Text'}
                  </span>
                  <span className="text-[10px] text-slate-500">{content.length} chars</span>
                </label>
                <textarea
                  required
                  rows={8}
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  placeholder={
                    activeTab === 'url'
                      ? 'https://login-account-update-portal.org/auth...'
                      : activeTab === 'email'
                      ? 'Paste email headers, SPF/DKIM tags, sender address, and body content...'
                      : 'Paste the message body, phone number, and any embedded links...'
                  }
                  className="w-full p-3 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={() => setContent('')}
                  className="text-xs text-slate-500 hover:text-slate-300 font-mono-code"
                >
                  Clear Input
                </button>
                <button
                  type="submit"
                  disabled={analyzing || !content.trim()}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] disabled:opacity-50 cursor-pointer flex items-center gap-2"
                >
                  {analyzing ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>Deconstructing Threat...</span>
                    </>
                  ) : (
                    <>
                      <Cpu className="w-4 h-4" />
                      <span>Execute Deep Inspection</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Engine Architecture Note */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] font-mono-code text-slate-400 space-y-1.5">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <Shield className="w-3.5 h-3.5" />
              <span>Zero-Day Safe Browsing Architecture</span>
            </div>
            <p className="text-[10px] leading-relaxed">
              Target URLs and payloads are parsed statically and cross-referenced with synthetic reasoning engines. Content is never executed or visited directly from your client browser.
            </p>
          </div>
        </div>

        {/* Right Column: Forensic Report Output */}
        <div className="lg:col-span-7">
          {analysisResult ? (
            <div className="p-6 rounded-2xl bg-[#070e1c] border border-cyan-500/30 shadow-2xl space-y-6">
              {/* Report Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono-code text-slate-400">ANALYSIS REPORT</span>
                    <span className="text-xs font-mono-code text-cyan-400 font-bold">{analysisResult.id}</span>
                  </div>
                  <h3 className="font-tech text-xl font-bold text-white mt-1">
                    {analysisResult.threatCategory}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyReport}
                    className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-mono-code flex items-center gap-1.5"
                    title="Copy Report"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </button>
                  <button
                    onClick={handleEscalate}
                    className="px-3 py-2 rounded-lg bg-red-600/90 hover:bg-red-500 text-white text-xs font-mono-code font-bold flex items-center gap-1.5 shadow-lg cursor-pointer"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>Escalate Incident</span>
                  </button>
                </div>
              </div>

              {/* Score Meter Banner */}
              {(() => {
                const colors = getScoreColor(analysisResult.riskScore);
                return (
                  <div className={`p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-[#0b172a] border ${colors.border} flex flex-col sm:flex-row sm:items-center justify-between gap-4`}>
                    <div className="flex items-center gap-4">
                      <div className="relative flex items-center justify-center">
                        <div className={`w-20 h-20 rounded-2xl ${colors.bg}/20 border ${colors.border} flex flex-col items-center justify-center shadow-lg`}>
                          <span className={`font-tech text-3xl font-extrabold ${colors.text}`}>
                            {analysisResult.riskScore}
                          </span>
                          <span className="text-[9px] font-mono-code text-slate-400 uppercase">/ 100</span>
                        </div>
                      </div>

                      <div>
                        <div className="text-[10px] font-mono-code uppercase tracking-wider text-slate-400">
                          Risk Classification
                        </div>
                        <div className={`font-tech text-2xl font-bold ${colors.text} uppercase`}>
                          {analysisResult.riskClassification}
                        </div>
                        <div className="text-[10px] font-mono-code text-slate-400 mt-0.5">
                          Confidence Level: <strong className="text-white">{analysisResult.confidenceScore}%</strong>
                        </div>
                      </div>
                    </div>

                    <div className="text-right font-mono-code text-[11px] text-slate-400 space-y-1">
                      <div>Engine: <span className="text-cyan-300">{analysisResult.engine}</span></div>
                      <div>Evaluated At: <span className="text-white">{new Date(analysisResult.analyzedAt).toLocaleTimeString()}</span></div>
                      {analysisResult.isSimulatedFallback && (
                        <div className="text-amber-400 text-[10px]">Heuristic Rule-Engine Assisted</div>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Detected Indicators */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono-code text-slate-400 uppercase tracking-wider font-bold">
                  Identified Threat Indicators ({analysisResult.indicators.length})
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {analysisResult.indicators.map((ind, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs font-mono-code flex items-start gap-2 text-slate-300"
                    >
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                      <span>{ind}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Detailed Explanation */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono-code text-slate-400 uppercase tracking-wider font-bold">
                  Forensic Pattern Deconstruction
                </h4>
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs font-mono-code text-slate-300 leading-relaxed space-y-2 whitespace-pre-line">
                  {analysisResult.explanation}
                </div>
              </div>

              {/* Recommended Mitigations */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono-code text-slate-400 uppercase tracking-wider font-bold flex items-center gap-1.5 text-cyan-400">
                  <CheckCircle2 className="w-4 h-4" />
                  Recommended SOC Safety Protocols
                </h4>
                <div className="space-y-2">
                  {analysisResult.recommendedActions.map((action, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-lg bg-cyan-950/20 border border-cyan-500/20 text-xs font-mono-code text-cyan-200 flex items-start gap-2"
                    >
                      <span className="text-cyan-400 font-bold">{i + 1}.</span>
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Regulatory / Scientific Limitation Note */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[10px] font-mono-code text-slate-500 flex items-start gap-2">
                <HelpCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-slate-400" />
                <span>
                  <strong>Advisory:</strong> AI risk evaluations are probabilistic threat estimations based on observable structural cues. Absence of detected markers does not guarantee absolute safety. Always verify high-impact transactions through out-of-band channels.
                </span>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center p-8 rounded-2xl bg-[#070e1c] border border-dashed border-cyan-500/20 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
                <Cpu className="w-8 h-8 text-cyan-400 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
                  Threat Engine Idle
                </h3>
                <p className="text-xs text-slate-400 font-mono-code max-w-sm">
                  Select a sample lure above or paste a suspicious URL, email header, or SMS text to engage the Gemini forensic inspection pipeline.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
