import React, { useState } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  Cpu,
  MailWarning,
  Eye,
  FileCheck2,
  FileText,
  Lock,
  ArrowRight,
  Terminal,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Zap,
  Layers,
  Send,
  Database,
  Search,
} from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { Footer } from '../components/Footer';
import { useToast } from '../contexts/ToastContext';

interface LandingPageProps {
  onNavigate: (page: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const { success, info } = useToast();
  const [currentPage, setCurrentPage] = useState('home');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMsg, setContactMsg] = useState('');
  const [contactSubmitting, setContactSubmitting] = useState(false);

  // Quick scan sandbox state
  const [quickInput, setQuickInput] = useState('');
  const [scanning, setScanning] = useState(false);
  const [quickResult, setQuickResult] = useState<any>(null);

  const handleQuickScan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    setScanning(true);
    setQuickResult(null);

    // Call server or simulate quick scan
    setTimeout(() => {
      setScanning(false);
      const isUrgent = quickInput.toLowerCase().includes('urgent') || quickInput.toLowerCase().includes('password') || quickInput.toLowerCase().includes('verify');
      setQuickResult({
        score: isUrgent ? 88 : 14,
        classification: isUrgent ? 'Critical Threat' : 'Safe / Baseline',
        type: quickInput.startsWith('http') ? 'URL Threat Analysis' : 'Message Vector',
        indicator: isUrgent ? 'Credential harvesting & coercive urgency markers detected' : 'Standard digital format without overt heuristic flags',
      });
      success('Sandbox scan complete! Redirecting to full SOC report in Threat Analyzer...');
    }, 1200);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMsg) return;
    setContactSubmitting(true);
    setTimeout(() => {
      setContactSubmitting(false);
      setContactName('');
      setContactEmail('');
      setContactMsg('');
      success('Emergency SOC Dispatch Received', 'Our cyber intelligence team has logged your dispatch notice.');
    }, 1000);
  };

  const scrollToSection = (id: string) => {
    setCurrentPage(id);
    if (id === 'login' || id === 'register' || id === 'dashboard') {
      onNavigate(id);
      return;
    }
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#050b14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Navigation */}
      <Navbar onNavigate={scrollToSection} currentPage={currentPage} />

      {/* Hero Section */}
      <section id="home" className="relative pt-32 pb-24 lg:pt-40 lg:pb-36 overflow-hidden">
        {/* Glow & Cyber grid effects */}
        <div className="absolute inset-0 cyber-grid opacity-60 pointer-events-none" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-cyan-600/10 blur-[130px] rounded-full pointer-events-none" />
        <div className="absolute top-1/3 right-1/4 w-[400px] h-[400px] bg-purple-600/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono-code">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                <span>CYBER DEFENSE INTELLIGENCE ENGINE v4.2</span>
              </div>

              <h1 className="font-tech text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white uppercase leading-tight">
                YOUR DIGITAL WORLD.{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400">
                  OUR SHIELD.
                </span>
              </h1>

              <p className="text-lg sm:text-xl text-slate-300 max-w-2xl font-light leading-relaxed">
                Detect threats. Investigate incidents. Protect your digital identity with intelligent cybersecurity powered by deep AI forensics.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4">
                <button
                  onClick={() => onNavigate('register')}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-blue-600 text-slate-950 font-bold text-sm tracking-wide transition-all shadow-[0_0_30px_rgba(6,182,212,0.5)] hover:shadow-[0_0_40px_rgba(6,182,212,0.7)] hover:scale-[1.02] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-slate-950" />
                  Get Started Free
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => scrollToSection('features')}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800/80 text-cyan-300 border border-cyan-500/30 hover:border-cyan-400/60 font-medium text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Terminal className="w-4 h-4 text-cyan-400" />
                  Explore CyberTrace
                </button>
              </div>

              {/* Floating Security Stats */}
              <div className="pt-8 grid grid-cols-3 gap-4 border-t border-slate-800/80 max-w-lg mx-auto lg:mx-0">
                <div>
                  <div className="font-tech text-2xl font-bold text-white">99.8%</div>
                  <div className="text-xs text-slate-400 font-mono-code">Phish Accuracy</div>
                </div>
                <div>
                  <div className="font-tech text-2xl font-bold text-cyan-400">1.2s</div>
                  <div className="text-xs text-slate-400 font-mono-code">Triage Latency</div>
                </div>
                <div>
                  <div className="font-tech text-2xl font-bold text-purple-400">45k+</div>
                  <div className="text-xs text-slate-400 font-mono-code">Threats Blocked</div>
                </div>
              </div>
            </div>

            {/* Right Interactive Animation Hologram / SOC Mockup */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md w-full p-6 rounded-2xl bg-gradient-to-b from-[#0a1529]/90 to-[#060c18]/90 border border-cyan-500/40 shadow-[0_0_50px_rgba(6,182,212,0.25)] backdrop-blur-xl overflow-hidden">
                {/* Scanner bar animation */}
                <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent scanline-anim z-20 opacity-70" />

                {/* Header */}
                <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20 text-xs font-mono-code">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    <span className="text-slate-400 ml-2">CYBERTRACE_SENTINEL.AI</span>
                  </div>
                  <span className="text-cyan-400">PORT 443 / TLS 1.3</span>
                </div>

                {/* Animated Alerts Stream */}
                <div className="py-6 space-y-3">
                  <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/40 flex items-center justify-between animate-pulse">
                    <div className="flex items-center gap-2.5">
                      <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
                      <div>
                        <div className="text-xs font-bold text-red-300 font-mono-code">PHISHING DETECTED</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[200px]">login-microsoft365-verify.com</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30">
                      RISK 96
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <MailWarning className="w-4 h-4 text-amber-400 shrink-0" />
                      <div>
                        <div className="text-xs font-bold text-amber-300 font-mono-code">FRAUD MESSAGE</div>
                        <div className="text-[11px] text-slate-400">Executive Wire Spoofing ($48.2k)</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      FLAGGED
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/40 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <Terminal className="w-4 h-4 text-purple-400 shrink-0" />
                      <div>
                        <div className="text-xs font-bold text-purple-300 font-mono-code">C2 BEACON INTERCEPTED</div>
                        <div className="text-[11px] text-slate-400">Memory Shellcode PID 8419 Terminated</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      INTERCEPTED
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                      <div>
                        <div className="text-xs font-bold text-emerald-300 font-mono-code">THREAT BLOCKED</div>
                        <div className="text-[11px] text-slate-400">Perimeter DNS Firewall Quarantined</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      CONTAINED
                    </span>
                  </div>
                </div>

                {/* Quick Live Interactive Scanner in Hero */}
                <form onSubmit={handleQuickScan} className="pt-2 border-t border-slate-800 space-y-2">
                  <div className="text-[11px] font-mono-code text-cyan-400 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5" />
                    Instant Sandbox Threat Scanner
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={quickInput}
                      onChange={e => setQuickInput(e.target.value)}
                      placeholder="Paste suspicious URL or message..."
                      className="w-full pl-3 pr-20 py-2 rounded-lg bg-slate-900 border border-cyan-500/30 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                    />
                    <button
                      type="submit"
                      disabled={scanning || !quickInput.trim()}
                      className="absolute right-1 top-1 bottom-1 px-3 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors disabled:opacity-50 cursor-pointer flex items-center gap-1"
                    >
                      {scanning ? '...' : 'Scan'}
                    </button>
                  </div>
                  {quickResult && (
                    <div className="p-2.5 rounded bg-cyan-950/50 border border-cyan-500/40 text-[11px] font-mono-code space-y-1 animate-in fade-in">
                      <div className="flex items-center justify-between">
                        <span className="text-white font-semibold">{quickResult.classification}</span>
                        <span className="text-cyan-300">Score: {quickResult.score}/100</span>
                      </div>
                      <p className="text-slate-300 text-[10px]">{quickResult.indicator}</p>
                      <button
                        type="button"
                        onClick={() => onNavigate('analyzer')}
                        className="text-cyan-400 hover:underline inline-block pt-1 text-[10px]"
                      >
                        Deep inspect in Threat Analyzer →
                      </button>
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Overview Section */}
      <section id="features" className="py-24 bg-[#040812] border-t border-cyan-500/10 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-xs font-mono-code uppercase tracking-widest text-cyan-400">
              Enterprise Defense Capabilities
            </h2>
            <p className="font-tech text-3xl sm:text-4xl font-bold text-white uppercase">
              Engineered For Modern High-Stakes Cyber Threats
            </p>
            <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
              CyberTrace combines cutting-edge AI reasoning models with NIST-compliant incident workflows, forensic integrity verification, and cybercrime intelligence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#091322] to-[#050b14] border border-cyan-500/20 hover:border-cyan-500/50 transition-all hover:shadow-[0_0_25px_rgba(6,182,212,0.2)] group">
              <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <MailWarning className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="font-tech text-xl font-bold text-white mb-2">1. AI Phishing Detection</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Real-time lexical, domain, and punycode analysis across email bodies, headers, and SMS. Identifies brand typosquatting, deceptive login redirects, and MFA-bypass kits.
              </p>
              <div className="text-xs font-mono-code text-cyan-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>View Engine Specs</span> →
              </div>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#091322] to-[#050b14] border border-cyan-500/20 hover:border-cyan-500/50 transition-all hover:shadow-[0_0_25px_rgba(6,182,212,0.2)] group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <ShieldAlert className="w-6 h-6 text-amber-400" />
              </div>
              <h3 className="font-tech text-xl font-bold text-white mb-2">2. Fraud Message Detection</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Detects urgent extortion language, fake payment receipts, CEO impersonation, and fraudulent crypto recovery schemes across WhatsApp, Telegram, and SMS.
              </p>
              <div className="text-xs font-mono-code text-amber-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>Explore Social Vectors</span> →
              </div>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#091322] to-[#050b14] border border-purple-500/20 hover:border-purple-500/50 transition-all hover:shadow-[0_0_25px_rgba(168,85,247,0.2)] group">
              <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <Cpu className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="font-tech text-xl font-bold text-white mb-2">3. AI Threat Intelligence</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Automated multi-modal lexical reasoning, credential theft deconstruction, and heuristic threat score evaluation with zero exposure risk.
              </p>
              <div className="text-xs font-mono-code text-purple-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>Threat Engine Specs</span> →
              </div>
            </div>

            {/* Feature 4 */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#091322] to-[#050b14] border border-cyan-500/20 hover:border-cyan-500/50 transition-all hover:shadow-[0_0_25px_rgba(6,182,212,0.2)] group">
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <Layers className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="font-tech text-xl font-bold text-white mb-2">4. Incident Management</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Enterprise SOC case lifecycle: Open, Investigating, Contained, Resolved. Dynamic severity triage, containment checklists, forensic timelines, and audit records.
              </p>
              <div className="text-xs font-mono-code text-blue-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>SOC Incident Tracker</span> →
              </div>
            </div>

            {/* Feature 5 */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#091322] to-[#050b14] border border-cyan-500/20 hover:border-cyan-500/50 transition-all hover:shadow-[0_0_25px_rgba(6,182,212,0.2)] group">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <FileCheck2 className="w-6 h-6 text-emerald-400" />
              </div>
              <h3 className="font-tech text-xl font-bold text-white mb-2">5. Digital Evidence Vault</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Cryptographic SHA-256 seal for screenshots, raw .eml emails, and memory dumps. Unbroken chain-of-custody logging with one-click tamper verification.
              </p>
              <div className="text-xs font-mono-code text-emerald-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>Forensic Chain of Custody</span> →
              </div>
            </div>

            {/* Feature 6 */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-[#091322] to-[#050b14] border border-cyan-500/20 hover:border-cyan-500/50 transition-all hover:shadow-[0_0_25px_rgba(6,182,212,0.2)] group">
              <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                <FileText className="w-6 h-6 text-rose-400" />
              </div>
              <h3 className="font-tech text-xl font-bold text-white mb-2">6. Cybercrime Reporting</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">
                Structured fraud intake producing automated Reference IDs (e.g. CT-CR-2026-XXXX). Formats complaints for law enforcement triage and evidence attachment.
              </p>
              <div className="text-xs font-mono-code text-rose-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>File Intake Protocol</span> →
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 bg-[#03070f] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="text-xs font-mono-code uppercase tracking-widest text-cyan-400">
              Operational Workflow
            </h2>
            <p className="font-tech text-3xl sm:text-4xl font-bold text-white uppercase">
              How CyberTrace Mitigates Incidents
            </p>
            <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
              From suspicious message intake to sealed evidence preservation in 4 streamlined steps.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 relative">
            {/* Step 1 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-cyan-500/20 relative">
              <div className="w-10 h-10 rounded-full bg-cyan-500 text-slate-950 font-tech font-bold text-lg flex items-center justify-center mb-4">
                01
              </div>
              <h4 className="font-tech text-lg font-bold text-white mb-2">Submit Suspicious Content</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Paste suspicious URLs, raw email headers, SMS lures, or log files into the analyzer interface.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-cyan-500/20 relative">
              <div className="w-10 h-10 rounded-full bg-blue-500 text-slate-950 font-tech font-bold text-lg flex items-center justify-center mb-4">
                02
              </div>
              <h4 className="font-tech text-lg font-bold text-white mb-2">AI Analyzes The Threat</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Gemini 3.8 Flash dissects attack vectors, urgency markers, typosquatting domains, and credential traps.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-cyan-500/20 relative">
              <div className="w-10 h-10 rounded-full bg-purple-500 text-slate-950 font-tech font-bold text-lg flex items-center justify-center mb-4">
                03
              </div>
              <h4 className="font-tech text-lg font-bold text-white mb-2">Receive Risk Assessment</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Get an objective 0–100 risk score, threat category breakdown, observable indicators, and actionable containment steps.
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-cyan-500/20 relative">
              <div className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 font-tech font-bold text-lg flex items-center justify-center mb-4">
                04
              </div>
              <h4 className="font-tech text-lg font-bold text-white mb-2">Report & Manage Incident</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Escalate directly to an active SOC incident, seal cryptographic SHA-256 evidence, and generate official complaint records.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-[#050b14] border-t border-cyan-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="text-xs font-mono-code uppercase tracking-widest text-cyan-400">
                Architecture & Mission
              </div>
              <h2 className="font-tech text-3xl sm:text-4xl font-bold text-white uppercase leading-tight">
                Built On Zero Trust & Cryptographic Integrity
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                CyberTrace was conceived to bridge the gap between complex cyber threat intelligence and frontline defenders. In an era where phishing kits and deepfakes can be spun up in seconds, incident response requires automated, transparent, and auditable tooling.
              </p>
              <div className="space-y-3 pt-2">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <span className="text-xs text-slate-300">
                    <strong className="text-white">Probabilistic AI Transparency:</strong> Clear labeling of uncertainty, confidence scores, and limitations on every automated scan.
                  </span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <span className="text-xs text-slate-300">
                    <strong className="text-white">Immutable Evidence Custody:</strong> Deterministic SHA-256 checksums prevent forensic tampering and support external legal handoffs.
                  </span>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                  <span className="text-xs text-slate-300">
                    <strong className="text-white">Enterprise Role Isolation:</strong> Configurable access policies for Incident Commanders, Tier-1 Analysts, and Auditors.
                  </span>
                </div>
              </div>
            </div>

            {/* Architecture Metrics Card */}
            <div className="p-8 rounded-2xl bg-[#091322] border border-cyan-500/30 space-y-6">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <span className="font-tech text-xl font-bold text-white">SOC Engine Specifications</span>
                <span className="text-xs font-mono-code px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  ACTIVE
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs font-mono-code">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-500">BACKEND RUNTIME</span>
                  <p className="text-white font-bold mt-1">Node.js Express + TSX</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-500">AI INFERENCE</span>
                  <p className="text-cyan-400 font-bold mt-1">Gemini 3.8 Flash</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-500">HASHING ALGORITHM</span>
                  <p className="text-purple-400 font-bold mt-1">FIPS 180-4 SHA-256</p>
                </div>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-500">AUTH & STORE</span>
                  <p className="text-emerald-400 font-bold mt-1">Supabase / RLS Ready</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-[#03070f] border-t border-cyan-500/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 space-y-3">
            <h2 className="text-xs font-mono-code uppercase tracking-widest text-cyan-400">
              Rapid Response
            </h2>
            <p className="font-tech text-3xl font-bold text-white uppercase">
              Emergency SOC Contact & Inquiries
            </p>
            <p className="text-slate-400 text-xs sm:text-sm">
              Need assistance evaluating a complex attack vector or setting up organizational telemetry? Dispatch an alert below.
            </p>
          </div>

          <form onSubmit={handleContactSubmit} className="p-8 rounded-2xl bg-[#081220] border border-cyan-500/30 space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-2">Complainant / Analyst Name</label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={e => setContactName(e.target.value)}
                  placeholder="e.g. Alex Morgan"
                  className="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                />
              </div>
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-2">Secure Contact Email</label>
                <input
                  type="email"
                  required
                  value={contactEmail}
                  onChange={e => setContactEmail(e.target.value)}
                  placeholder="alex.m@organization.com"
                  className="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono-code text-slate-300 mb-2">Urgency / Briefing Details</label>
              <textarea
                required
                rows={4}
                value={contactMsg}
                onChange={e => setContactMsg(e.target.value)}
                placeholder="Describe suspected breach scope, affected domains, or general platform inquiries..."
                className="w-full px-4 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
              />
            </div>

            <button
              type="submit"
              disabled={contactSubmitting}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all"
            >
              <Send className="w-4 h-4" />
              {contactSubmitting ? 'Transmitting Dispatch...' : 'Dispatch Message to SOC Team'}
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <Footer onNavigate={scrollToSection} />
    </div>
  );
};
