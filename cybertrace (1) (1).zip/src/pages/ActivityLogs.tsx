import React, { useState, useEffect } from 'react';
import {
  Activity,
  Search,
  Filter,
  RefreshCw,
  Shield,
  Download,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Terminal,
} from 'lucide-react';
import { api } from '../lib/api';
import { ActivityLog } from '../types';
import { useToast } from '../contexts/ToastContext';

export const ActivityLogs: React.FC = () => {
  const { success, error: toastError, info } = useToast();
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAction, setFilterAction] = useState('ALL');

  const loadLogs = async () => {
    try {
      setLoading(true);
      const res = await api.getActivityLogs();
      setLogs(res.logs || []);
    } catch (err: any) {
      toastError('Failed to load activity logs', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  const actionTypes = [
    'ALL',
    'LOGIN',
    'LOGOUT',
    'INCIDENT_CREATED',
    'INCIDENT_UPDATED',
    'EVIDENCE_UPLOADED',
    'THREAT_ANALYZED',
    'REPORT_FILED',
    'SYSTEM_ALERT',
  ];

  const filteredLogs = logs.filter(log => {
    if (filterAction !== 'ALL' && log.action !== filterAction) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        log.details.toLowerCase().includes(q) ||
        log.user.toLowerCase().includes(q) ||
        log.ipAddress.toLowerCase().includes(q) ||
        log.action.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportCSV = () => {
    const csvHeader = 'Timestamp,User,Action,Severity,IP,Details\n';
    const csvRows = filteredLogs.map(l =>
      `"${l.timestamp}","${l.user}","${l.action}","${l.severity}","${l.ipAddress}","${l.details.replace(/"/g, '""')}"`
    );
    const blob = new Blob([csvHeader + csvRows.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cybertrace_audit_logs_${Date.now()}.csv`;
    a.click();
    success('Audit Log Exported', 'CSV download generated for compliance records.');
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
              SOC Activity & Audit Logs
            </h1>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold uppercase">
              SIEM STREAM
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono-code mt-1">
            Immutable Audit Trail • Analyst Operations • Threat Ingestion Events
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadLogs}
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-mono-code flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-xs font-mono-code flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="p-4 rounded-xl bg-[#070e1c] border border-cyan-500/20 flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search logs by IP, action, operator, or content..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
          />
        </div>

        <div className="w-full sm:w-auto">
          <select
            value={filterAction}
            onChange={e => setFilterAction(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400 font-mono-code cursor-pointer"
          >
            {actionTypes.map(act => (
              <option key={act} value={act}>
                {act === 'ALL' ? 'All Action Types' : act}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Activity Logs Table */}
      <div className="rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl overflow-hidden font-mono-code text-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#0b162c] text-slate-400 border-b border-cyan-500/20">
              <tr>
                <th className="py-3 px-4">TIMESTAMP</th>
                <th className="py-3 px-4">OPERATOR</th>
                <th className="py-3 px-4">EVENT TYPE</th>
                <th className="py-3 px-4">IP ORIGIN</th>
                <th className="py-3 px-4">EVENT DESCRIPTION & TELEMETRY</th>
                <th className="py-3 px-4">LEVEL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredLogs.map(log => {
                let badgeClass = 'text-cyan-400 bg-cyan-950/60 border-cyan-500/30';
                if (log.severity === 'alert') badgeClass = 'text-red-400 bg-red-950/60 border-red-500/40';
                else if (log.severity === 'warning') badgeClass = 'text-amber-400 bg-amber-950/60 border-amber-500/40';
                else if (log.severity === 'success') badgeClass = 'text-emerald-400 bg-emerald-950/60 border-emerald-500/40';

                return (
                  <tr key={log.id} className="hover:bg-cyan-950/10 transition-colors">
                    <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-white font-semibold whitespace-nowrap">
                      {log.user}
                    </td>
                    <td className="py-3 px-4 font-bold text-cyan-300 whitespace-nowrap">
                      {log.action}
                    </td>
                    <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                      {log.ipAddress}
                    </td>
                    <td className="py-3 px-4 text-slate-200 leading-relaxed max-w-md">
                      {log.details}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${badgeClass}`}>
                        {log.severity.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
