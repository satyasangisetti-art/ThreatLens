import React, { useState, useEffect, useRef } from 'react';
import {
  FileCheck2,
  Upload,
  Hash,
  ShieldCheck,
  ShieldAlert,
  Clock,
  Download,
  Trash2,
  RefreshCw,
  Search,
  Plus,
  FileText,
  FileCode,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  X,
  Lock,
} from 'lucide-react';
import { api } from '../lib/api';
import { EvidenceFile, Incident } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

export const EvidenceVault: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError, info } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [evidenceList, setEvidenceList] = useState<EvidenceFile[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterIncident, setFilterIncident] = useState('All');

  // Upload modal state
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string>('');
  const [linkedIncidentId, setLinkedIncidentId] = useState('');
  const [notes, setNotes] = useState('');
  const [uploading, setUploading] = useState(false);

  // Verifying state per evidence
  const [verifyingId, setVerifyingId] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [eviRes, incRes] = await Promise.all([
        api.getEvidence(filterIncident !== 'All' ? filterIncident : undefined),
        api.getIncidents(),
      ]);
      setEvidenceList(eviRes.evidence || []);
      setIncidents(incRes.incidents || []);
    } catch (err: any) {
      toastError('Failed to load Evidence Vault', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [filterIncident]);

  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setFileBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;

    setUploading(true);
    try {
      const res = await api.uploadEvidence({
        filename: selectedFile.name,
        fileBase64: fileBase64 || undefined,
        fileSize: selectedFile.size,
        fileType: selectedFile.type || 'application/octet-stream',
        incidentId: linkedIncidentId || undefined,
        notes: notes.trim(),
        uploadedBy: user?.name || 'Forensic Specialist',
      });

      success('Evidence Sealed', `SHA-256 hash calculated: ${res.evidence.sha256Hash.substring(0, 16)}...`);
      setUploadModalOpen(false);
      setSelectedFile(null);
      setFileBase64('');
      setNotes('');
      setLinkedIncidentId('');
      loadData();
    } catch (err: any) {
      toastError('Upload Failed', err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleVerifyIntegrity = async (id: string, filename: string) => {
    setVerifyingId(id);
    try {
      const res = await api.verifyEvidence(id);
      success('Integrity Verified', `File "${filename}" SHA-256 matches sealed custody record.`);
      loadData();
    } catch (err: any) {
      toastError('Integrity Verification Failed', err.message);
    } finally {
      setVerifyingId(null);
    }
  };

  const handleDeleteEvidence = async (id: string) => {
    if (!confirm('Are you sure you want to remove this piece of evidence?')) return;
    try {
      await api.deleteEvidence(id);
      success('Evidence Removed', 'Record purged from vault.');
      loadData();
    } catch (err: any) {
      toastError('Failed to remove evidence', err.message);
    }
  };

  const filteredEvidence = evidenceList.filter(e => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      e.filename.toLowerCase().includes(q) ||
      e.sha256Hash.toLowerCase().includes(q) ||
      e.uploadedBy.toLowerCase().includes(q) ||
      e.id.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
              Digital Evidence Vault
            </h1>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold uppercase flex items-center gap-1">
              <Lock className="w-3 h-3 text-cyan-400" />
              FIPS 180-4 SHA-256
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono-code mt-1">
            Tamper-Evident Forensic Custody • Cryptographic Checksums • Chain-of-Custody Attestation
          </p>
        </div>

        <button
          onClick={() => setUploadModalOpen(true)}
          className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Seal New Evidence
        </button>
      </div>

      {/* Chain-of-Custody Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono-code text-xs">
        <div className="p-4 rounded-xl bg-[#070e1c] border border-cyan-500/20 flex items-center justify-between">
          <div>
            <span className="text-slate-400">Total Sealed Artifacts</span>
            <div className="font-tech text-2xl font-bold text-white mt-1">{evidenceList.length}</div>
          </div>
          <FileCheck2 className="w-7 h-7 text-cyan-400" />
        </div>

        <div className="p-4 rounded-xl bg-[#070e1c] border border-emerald-500/20 flex items-center justify-between">
          <div>
            <span className="text-slate-400">Integrity Verified</span>
            <div className="font-tech text-2xl font-bold text-emerald-400 mt-1">
              {evidenceList.filter(e => e.integrityVerified).length} / {evidenceList.length}
            </div>
          </div>
          <ShieldCheck className="w-7 h-7 text-emerald-400" />
        </div>

        <div className="p-4 rounded-xl bg-[#070e1c] border border-purple-500/20 flex items-center justify-between">
          <div>
            <span className="text-slate-400">Hashing Standard</span>
            <div className="font-tech text-lg font-bold text-purple-300 mt-1">SHA-256 (256-bit)</div>
          </div>
          <Hash className="w-7 h-7 text-purple-400" />
        </div>
      </div>

      {/* Toolbar */}
      <div className="p-4 rounded-xl bg-[#070e1c] border border-cyan-500/20 flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by filename, SHA-256 hash, or analyst..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
          />
        </div>

        <div className="w-full sm:w-auto">
          <select
            value={filterIncident}
            onChange={e => setFilterIncident(e.target.value)}
            className="w-full sm:w-auto px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400 font-mono-code cursor-pointer"
          >
            <option value="All">All Linked Incidents</option>
            {incidents.map(inc => (
              <option key={inc.id} value={inc.id}>
                {inc.incidentNumber} - {inc.title.substring(0, 30)}...
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Evidence Table */}
      <div className="rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-code">
            <thead className="bg-[#0b162c] text-slate-400 border-b border-cyan-500/20">
              <tr>
                <th className="py-3 px-4">EVIDENCE ID</th>
                <th className="py-3 px-4">FILE NAME & TYPE</th>
                <th className="py-3 px-4">SHA-256 CRYPTOGRAPHIC HASH</th>
                <th className="py-3 px-4">LINKED INCIDENT</th>
                <th className="py-3 px-4">UPLOADED BY / DATE</th>
                <th className="py-3 px-4">INTEGRITY</th>
                <th className="py-3 px-4 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredEvidence.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No evidence items currently secured matching your search.
                  </td>
                </tr>
              ) : (
                filteredEvidence.map(ev => {
                  const linkedInc = incidents.find(i => i.id === ev.incidentId);

                  return (
                    <tr key={ev.id} className="hover:bg-cyan-950/15 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-cyan-400">
                        {ev.id}
                      </td>
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="font-semibold text-white truncate">{ev.filename}</div>
                        <div className="text-[10px] text-slate-400">
                          {(ev.fileSize / 1024).toFixed(1)} KB • {ev.fileType}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 max-w-sm">
                        <div className="flex items-center gap-1.5 font-mono-code text-[11px] text-cyan-300 bg-slate-900/90 px-2 py-1 rounded border border-cyan-500/20 truncate">
                          <Hash className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                          <span className="truncate">{ev.sha256Hash}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        {linkedInc ? (
                          <span className="px-2 py-0.5 rounded text-[10px] bg-slate-900 text-cyan-300 border border-slate-700">
                            {linkedInc.incidentNumber}
                          </span>
                        ) : (
                          <span className="text-slate-500">Unassigned</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        <div>{ev.uploadedBy}</div>
                        <div className="text-[10px] text-slate-500">
                          {new Date(ev.uploadedAt).toLocaleString()}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        {ev.integrityVerified ? (
                          <span className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-500/40">
                            <ShieldCheck className="w-3 h-3 text-emerald-400" />
                            CONFIRMED
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-amber-950/80 text-amber-300 border border-amber-500/40">
                            UNCHECKED
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right space-x-2">
                        <button
                          onClick={() => handleVerifyIntegrity(ev.id, ev.filename)}
                          disabled={verifyingId === ev.id}
                          className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-cyan-400 text-cyan-300 text-[10px] transition-colors"
                        >
                          {verifyingId === ev.id ? 'Rehashing...' : 'Verify Hash'}
                        </button>
                        <button
                          onClick={() => handleDeleteEvidence(ev.id)}
                          className="p-1 rounded text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
                          title="Purge Evidence"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* UPLOAD EVIDENCE MODAL */}
      {uploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#091424] border border-cyan-500/40 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
                  Secure Evidence Ingestion
                </h3>
              </div>
              <button onClick={() => setUploadModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadSubmit} className="py-4 space-y-4 font-mono-code text-xs">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFilePicked}
                className="hidden"
              />

              {selectedFile ? (
                <div className="p-4 rounded-xl bg-slate-900 border border-cyan-500/30 space-y-2">
                  <div className="flex items-center justify-between text-white font-semibold">
                    <span className="truncate max-w-xs">{selectedFile.name}</span>
                    <span className="text-cyan-400">{(selectedFile.size / 1024).toFixed(1)} KB</span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Type: {selectedFile.type || 'Binary / Raw'}
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-[10px] text-cyan-400 hover:underline pt-1"
                  >
                    Change Selected File
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="p-8 border-2 border-dashed border-cyan-500/30 hover:border-cyan-400 rounded-xl flex flex-col items-center justify-center text-center cursor-pointer bg-slate-900/40 hover:bg-slate-900/70 transition-colors"
                >
                  <Upload className="w-8 h-8 text-cyan-400 mb-2" />
                  <p className="text-white font-semibold mb-1">Click to Select Evidence Artifact</p>
                  <p className="text-[10px] text-slate-400">Screenshots, .eml headers, PDF receipts, or log memory files</p>
                </div>
              )}

              <div>
                <label className="block text-slate-300 mb-1">Link to Active Incident (Optional)</label>
                <select
                  value={linkedIncidentId}
                  onChange={e => setLinkedIncidentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="">None (Independent Vault Entry)</option>
                  {incidents.map(inc => (
                    <option key={inc.id} value={inc.id}>
                      {inc.incidentNumber} - {inc.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Chain of Custody Notes</label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Record source workstation, acquisition methodology, and handling instructions..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setUploadModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={uploading || !selectedFile}
                  className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase disabled:opacity-50 transition-colors shadow-md cursor-pointer"
                >
                  {uploading ? 'Sealing Artifact...' : 'Calculate SHA-256 & Seal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
