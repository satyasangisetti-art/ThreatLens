import React, { useState } from 'react';
import {
  Shield,
  Lock,
  Mail,
  User,
  Building,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  KeyRound,
  CheckCircle2,
  ChevronLeft,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

interface AuthPageProps {
  initialMode?: 'login' | 'register';
  onNavigate: (page: string) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ initialMode = 'login', onNavigate }) => {
  const { login, register, resetPassword, demoLogin, isSupabaseMode } = useAuth();
  const { success, error: toastError, info } = useToast();

  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [organization, setOrganization] = useState('');
  const [role, setRole] = useState<'SOC Analyst' | 'Incident Commander' | 'Threat Hunter' | 'Security Admin'>('SOC Analyst');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSubmitting(true);

    try {
      if (mode === 'login') {
        await login(email, password);
        success('Access Granted', 'Authenticated to CyberTrace Security Operations Center.');
        onNavigate('dashboard');
      } else if (mode === 'register') {
        await register(email, password, name, organization);
        success('Account Enrolled', 'Your analyst profile is created and verified.');
        onNavigate('dashboard');
      } else if (mode === 'forgot') {
        await resetPassword(email);
        success('Password Reset Initiated', `Instructions dispatched to ${email}. Check your inbox.`);
        setMode('login');
      }
    } catch (err: any) {
      const msg = err?.message || 'Authentication failed. Please verify credentials.';
      setErrorMsg(msg);
      toastError('Authentication Alert', msg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDemoSignIn = async (roleType: 'analyst' | 'admin') => {
    setErrorMsg('');
    setSubmitting(true);
    try {
      await demoLogin(roleType);
      success('SOC Demo Credentials Loaded', `Logged in as ${roleType === 'admin' ? 'Sri Harsha (Security Admin)' : 'Sarah Chen (Incident Commander)'}.`);
      onNavigate('dashboard');
    } catch (err: any) {
      setErrorMsg(err?.message || 'Demo login failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#040812] text-slate-100 flex flex-col justify-center items-center p-4 relative overflow-hidden cyber-grid">
      {/* Background radial glow */}
      <div className="absolute w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none -top-20 -left-20" />
      <div className="absolute w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[120px] pointer-events-none -bottom-20 -right-20" />

      {/* Top back navigation */}
      <button
        onClick={() => onNavigate('home')}
        className="absolute top-6 left-6 flex items-center gap-1.5 text-xs font-mono-code text-slate-400 hover:text-cyan-400 transition-colors cursor-pointer"
      >
        <ChevronLeft className="w-4 h-4" />
        Return to CyberTrace Home
      </button>

      {/* Auth Card */}
      <div className="w-full max-w-md relative z-10">
        <div className="p-8 rounded-2xl bg-gradient-to-b from-[#091424]/95 to-[#050b14]/95 border border-cyan-500/30 shadow-[0_0_50px_rgba(6,182,212,0.25)] backdrop-blur-xl">
          {/* Brand Header */}
          <div className="text-center mb-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-500/40 mx-auto flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.4)] mb-3">
              <Shield className="w-6 h-6 text-cyan-400" />
            </div>
            <h1 className="font-tech text-2xl font-bold tracking-wider text-white">
              CYBER<span className="text-cyan-400">TRACE</span>
            </h1>
            <p className="text-xs text-slate-400 font-mono-code mt-1 uppercase tracking-wider">
              {mode === 'login'
                ? 'SOC Analyst Authentication'
                : mode === 'register'
                ? 'Security Operator Enrollment'
                : 'Credential Recovery Dispatch'}
            </p>
          </div>

          {/* Mode Switch Tabs */}
          {mode !== 'forgot' && (
            <div className="grid grid-cols-2 p-1 rounded-xl bg-slate-900 border border-slate-800 mb-6 text-xs font-mono-code">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setErrorMsg('');
                }}
                className={`py-2 rounded-lg font-medium transition-all ${
                  mode === 'login'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setErrorMsg('');
                }}
                className={`py-2 rounded-lg font-medium transition-all ${
                  mode === 'register'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Create Account
              </button>
            </div>
          )}

          {/* Error notice */}
          {errorMsg && (
            <div className="mb-4 p-3 rounded-lg bg-red-950/60 border border-red-500/40 text-xs text-red-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'register' && (
              <>
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1.5">Full Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="e.g. Sarah Chen"
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1.5">Organization / Unit</label>
                  <div className="relative">
                    <Building className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={organization}
                      onChange={e => setOrganization(e.target.value)}
                      placeholder="e.g. CyberTrace SOC Alpha"
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1.5">SOC Role</label>
                  <select
                    value={role}
                    onChange={e => setRole(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400 font-mono-code"
                  >
                    <option value="SOC Analyst">SOC Analyst</option>
                    <option value="Incident Commander">Incident Commander</option>
                    <option value="Threat Hunter">Threat Hunter</option>
                    <option value="Security Admin">Security Admin</option>
                  </select>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-mono-code text-slate-300 mb-1.5">Corporate / Secure Email</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="analyst@cybertrace.io"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-mono-code text-slate-300">Access Key / Password</label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('forgot');
                        setErrorMsg('');
                      }}
                      className="text-[11px] text-cyan-400 hover:underline font-mono-code"
                    >
                      Forgot access key?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-9 pr-10 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(6,182,212,0.3)] disabled:opacity-50 cursor-pointer mt-2"
            >
              {submitting ? (
                <span>Authenticating with SOC Gateway...</span>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  {mode === 'login' ? 'Authenticate Console' : mode === 'register' ? 'Register Security Key' : 'Transmit Reset Link'}
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {mode === 'forgot' && (
            <div className="text-center mt-4">
              <button
                type="button"
                onClick={() => setMode('login')}
                className="text-xs text-cyan-400 hover:underline font-mono-code"
              >
                ← Back to Login
              </button>
            </div>
          )}

          {/* Quick Demo Logins for Evaluator Ease */}
          <div className="mt-8 pt-6 border-t border-slate-800/80">
            <div className="text-[10px] font-mono-code text-slate-400 uppercase tracking-widest text-center mb-3">
              Fast Evaluator Demo Access
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleDemoSignIn('analyst')}
                className="p-2 rounded-lg bg-slate-900/90 border border-cyan-500/30 hover:border-cyan-400 text-left transition-all group"
              >
                <div className="text-[11px] font-semibold text-white group-hover:text-cyan-300">Sarah Chen</div>
                <div className="text-[10px] text-cyan-400 font-mono-code">Incident Commander</div>
              </button>

              <button
                type="button"
                onClick={() => handleDemoSignIn('admin')}
                className="p-2 rounded-lg bg-slate-900/90 border border-purple-500/30 hover:border-purple-400 text-left transition-all group"
              >
                <div className="text-[11px] font-semibold text-white group-hover:text-purple-300">Sri Harsha</div>
                <div className="text-[10px] text-purple-400 font-mono-code">Security Admin</div>
              </button>
            </div>
          </div>
        </div>

        {/* Footnote */}
        <div className="text-center mt-4 text-[11px] text-slate-500 font-mono-code">
          {isSupabaseMode ? 'Supabase Auth & RLS Connected' : 'CyberTrace Local SOC Session Persistence Active'}
        </div>
      </div>
    </div>
  );
};
