import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Search,
  Filter,
  Plus,
  Trash2,
  Edit3,
  Clock,
  CheckCircle2,
  AlertCircle,
  Eye,
  FileCheck2,
  X,
  ChevronDown,
  ArrowUpDown,
  UserCheck,
  Send,
  Building,
} from 'lucide-react';
import { api } from '../lib/api';
import { Incident, EvidenceFile } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

export const IncidentManagement: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError, warning } = useToast();

  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSeverity, setSelectedSeverity] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [relatedEvidence, setRelatedEvidence] = useState<EvidenceFile[]>([]);
  const [newTimelineNote, setNewTimelineNote] = useState('');
  const [addingTimelineNote, setAddingTimelineNote] = useState(false);

  // Form states
  const [formTitle, setFormTitle] = useState('');
  const [formCategory, setFormCategory] = useState<Incident['category']>('Phishing');
  const [formSeverity, setFormSeverity] = useState<Incident['severity']>('High');
  const [formStatus, setFormStatus] = useState<Incident['status']>('Open');
  const [formDescription, setFormDescription] = useState('');
  const [formAffectedSystem, setFormAffectedSystem] = useState('');
  const [formAssignedInvestigator, setFormAssignedInvestigator] = useState('Sarah Chen');
  const [submittingForm, setSubmittingForm] = useState(false);

  const categories = [
    'Phishing',
    'Malware',
    'Ransomware',
    'Data Breach',
    'Unauthorized Access',
    'DDoS Attack',
    'Financial Fraud',
    'Identity Theft',
    'Social Engineering',
    'Other',
  ];

  const severities = ['Critical', 'High', 'Medium', 'Low'];
  const statuses = ['Open', 'Investigating', 'Contained', 'Resolved'];

  const loadIncidents = async () => {
    try {
      setLoading(true);
      const res = await api.getIncidents({
        category: selectedCategory !== 'All' ? selectedCategory : undefined,
        severity: selectedSeverity !== 'All' ? selectedSeverity : undefined,
        status: selectedStatus !== 'All' ? selectedStatus : undefined,
        search: searchQuery.trim() || undefined,
      });
      setIncidents(res.incidents || []);
    } catch (err: any) {
      toastError('Failed to load incidents', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadIncidents();
  }, [selectedCategory, selectedSeverity, selectedStatus, sortOrder]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loadIncidents();
  };

  const openCreateModal = () => {
    setFormTitle('');
    setFormCategory('Phishing');
    setFormSeverity('High');
    setFormStatus('Open');
    setFormDescription('');
    setFormAffectedSystem('Production Host / Perimeter DNS');
    setFormAssignedInvestigator(user?.name || 'Sarah Chen');
    setCreateModalOpen(true);
  };

  const handleCreateIncident = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formDescription) return;
    setSubmittingForm(true);
    try {
      const res = await api.createIncident({
        title: formTitle,
        category: formCategory,
        severity: formSeverity,
        status: formStatus,
        description: formDescription,
        affectedSystem: formAffectedSystem,
        assignedInvestigator: formAssignedInvestigator,
      });
      success('Incident Created', `Case ${res.incident.incidentNumber} initiated.`);
      setCreateModalOpen(false);
      loadIncidents();
    } catch (err: any) {
      toastError('Creation Failed', err.message);
    } finally {
      setSubmittingForm(false);
    }
  };

  const openDetailsModal = async (inc: Incident) => {
    setSelectedIncident(inc);
    setDetailsModalOpen(true);
    try {
      const res = await api.getIncidentById(inc.id);
      setSelectedIncident(res.incident);
      setRelatedEvidence(res.relatedEvidence || []);
    } catch (err) {
      // Keep existing
    }
  };

  const openEditModal = (inc: Incident) => {
    setSelectedIncident(inc);
    setFormTitle(inc.title);
    setFormCategory(inc.category);
    setFormSeverity(inc.severity);
    setFormStatus(inc.status);
    setFormDescription(inc.description);
    setFormAffectedSystem(inc.affectedSystem);
    setFormAssignedInvestigator(inc.assignedInvestigator);
    setEditModalOpen(true);
  };

  const handleEditIncident = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIncident) return;
    setSubmittingForm(true);
    try {
      const res = await api.updateIncident(selectedIncident.id, {
        title: formTitle,
        category: formCategory,
        severity: formSeverity,
        status: formStatus,
        description: formDescription,
        affectedSystem: formAffectedSystem,
        assignedInvestigator: formAssignedInvestigator,
      });
      success('Incident Updated', `Case ${res.incident.incidentNumber} parameters saved.`);
      setEditModalOpen(false);
      setSelectedIncident(res.incident);
      loadIncidents();
    } catch (err: any) {
      toastError('Update Failed', err.message);
    } finally {
      setSubmittingForm(false);
    }
  };

  const handleAddTimelineNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedIncident || !newTimelineNote.trim()) return;
    setAddingTimelineNote(true);
    try {
      const res = await api.updateIncident(selectedIncident.id, {
        newTimelineNote: newTimelineNote.trim(),
      });
      setSelectedIncident(res.incident);
      setNewTimelineNote('');
      success('Forensic Note Added', 'Timeline record appended to case.');
      loadIncidents();
    } catch (err: any) {
      toastError('Failed to append note', err.message);
    } finally {
      setAddingTimelineNote(false);
    }
  };

  const handleQuickStatusChange = async (inc: Incident, newStatus: Incident['status']) => {
    try {
      const res = await api.updateIncident(inc.id, { status: newStatus });
      success('Status Transitioned', `${inc.incidentNumber} is now ${newStatus}`);
      if (selectedIncident?.id === inc.id) {
        setSelectedIncident(res.incident);
      }
      loadIncidents();
    } catch (err: any) {
      toastError('Status Update Failed', err.message);
    }
  };

  const handleDeleteIncident = async (id: string) => {
    try {
      await api.deleteIncident(id);
      success('Incident Purged', 'Record permanently removed from SOC database.');
      setDeleteConfirmId(null);
      if (selectedIncident?.id === id) setDetailsModalOpen(false);
      loadIncidents();
    } catch (err: any) {
      toastError('Delete Failed', err.message);
    }
  };

  // Metrics summary
  const total = incidents.length;
  const criticalCount = incidents.filter(i => i.severity === 'Critical').length;
  const investigatingCount = incidents.filter(i => i.status === 'Investigating').length;
  const resolvedCount = incidents.filter(i => i.status === 'Resolved').length;

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
              Incident Management
            </h1>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold uppercase">
              CASE LOG
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono-code mt-1">
            Enterprise Incident Triage, Containment Workflows, & Forensic Timelines
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Create New Incident
        </button>
      </div>

      {/* Mini Stat Tickers */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-code text-xs">
        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <span className="text-slate-400">Total Cases</span>
          <span className="font-tech text-lg font-bold text-white">{total}</span>
        </div>
        <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/30 flex items-center justify-between">
          <span className="text-red-300">Critical Severity</span>
          <span className="font-tech text-lg font-bold text-red-400">{criticalCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/30 flex items-center justify-between">
          <span className="text-purple-300">Investigating</span>
          <span className="font-tech text-lg font-bold text-purple-400">{investigatingCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
          <span className="text-emerald-300">Resolved SLA</span>
          <span className="font-tech text-lg font-bold text-emerald-400">{resolvedCount}</span>
        </div>
      </div>

      {/* Filters & Search Toolbar */}
      <div className="p-4 rounded-xl bg-[#070e1c] border border-cyan-500/20 space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3">
          {/* Search */}
          <form onSubmit={handleSearchSubmit} className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search by Case Number, Title, Host, or Investigator..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
            />
          </form>

          {/* Category Filter */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400 font-mono-code cursor-pointer w-full md:w-auto"
            >
              <option value="All">All Categories</option>
              {categories.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            {/* Severity Filter */}
            <select
              value={selectedSeverity}
              onChange={e => setSelectedSeverity(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400 font-mono-code cursor-pointer w-full md:w-auto"
            >
              <option value="All">All Severities</option>
              {severities.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>

            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={e => setSelectedStatus(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-slate-200 focus:outline-none focus:border-cyan-400 font-mono-code cursor-pointer w-full md:w-auto"
            >
              <option value="All">All Statuses</option>
              {statuses.map(st => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Incidents Data Table */}
      <div className="rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono-code">
            <thead className="bg-[#0b162c] text-slate-400 border-b border-cyan-500/20">
              <tr>
                <th className="py-3 px-4">INCIDENT ID</th>
                <th className="py-3 px-4">TITLE & IMPACT</th>
                <th className="py-3 px-4">CATEGORY</th>
                <th className="py-3 px-4">SEVERITY</th>
                <th className="py-3 px-4">STATUS</th>
                <th className="py-3 px-4">INVESTIGATOR</th>
                <th className="py-3 px-4">EVIDENCE</th>
                <th className="py-3 px-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {incidents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    No incidents match the active search or filter criteria.
                  </td>
                </tr>
              ) : (
                incidents.map(inc => {
                  let sevBadge = 'text-cyan-400 bg-cyan-950/60 border-cyan-500/40';
                  if (inc.severity === 'Critical') sevBadge = 'text-red-400 bg-red-950/60 border-red-500/40 animate-pulse';
                  else if (inc.severity === 'High') sevBadge = 'text-amber-400 bg-amber-950/60 border-amber-500/40';
                  else if (inc.severity === 'Medium') sevBadge = 'text-yellow-400 bg-yellow-950/60 border-yellow-500/40';

                  let statusBadge = 'text-blue-400 bg-blue-950/60 border-blue-500/30';
                  if (inc.status === 'Resolved') statusBadge = 'text-emerald-400 bg-emerald-950/60 border-emerald-500/40';
                  else if (inc.status === 'Investigating') statusBadge = 'text-purple-400 bg-purple-950/60 border-purple-500/40';
                  else if (inc.status === 'Contained') statusBadge = 'text-cyan-400 bg-cyan-950/60 border-cyan-500/40';

                  return (
                    <tr
                      key={inc.id}
                      className="hover:bg-cyan-950/15 transition-colors group cursor-pointer"
                      onClick={() => openDetailsModal(inc)}
                    >
                      <td className="py-3.5 px-4 font-bold text-cyan-400">
                        {inc.incidentNumber}
                      </td>
                      <td className="py-3.5 px-4 max-w-sm">
                        <div className="font-semibold text-white group-hover:text-cyan-200 truncate">
                          {inc.title}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate mt-0.5">
                          Affected: {inc.affectedSystem}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {inc.category}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${sevBadge}`}>
                          {inc.severity}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <select
                          value={inc.status}
                          onClick={e => e.stopPropagation()}
                          onChange={e => handleQuickStatusChange(inc, e.target.value as any)}
                          className={`px-2 py-0.5 rounded text-[10px] border font-bold ${statusBadge} bg-transparent cursor-pointer focus:outline-none`}
                        >
                          {statuses.map(st => (
                            <option key={st} value={st} className="bg-slate-900 text-white">
                              {st}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {inc.assignedInvestigator}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        <span className="flex items-center gap-1">
                          <FileCheck2 className="w-3.5 h-3.5 text-cyan-400" />
                          {inc.evidenceCount || 0}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right space-x-2" onClick={e => e.stopPropagation()}>
                        <button
                          onClick={() => openEditModal(inc)}
                          title="Edit Incident"
                          className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmId(inc.id)}
                          title="Purge Incident"
                          className="p-1 rounded text-slate-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE INCIDENT MODAL */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#091424] border border-cyan-500/40 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-cyan-400" />
                <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
                  Create Incident Case
                </h3>
              </div>
              <button onClick={() => setCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateIncident} className="py-4 space-y-4">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">Incident Title</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder="e.g. Distributed Credential Stuffing on VPN Endpoint"
                  className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400 font-mono-code"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Severity</label>
                  <select
                    value={formSeverity}
                    onChange={e => setFormSeverity(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400 font-mono-code"
                  >
                    {severities.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Affected System / Asset</label>
                  <input
                    type="text"
                    value={formAffectedSystem}
                    onChange={e => setFormAffectedSystem(e.target.value)}
                    placeholder="e.g. AWS-EKS-AUTH-01"
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Assigned Investigator</label>
                  <input
                    type="text"
                    value={formAssignedInvestigator}
                    onChange={e => setFormAssignedInvestigator(e.target.value)}
                    placeholder="Sarah Chen"
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">Description & Threat Vector</label>
                <textarea
                  required
                  rows={3}
                  value={formDescription}
                  onChange={e => setFormDescription(e.target.value)}
                  placeholder="Detail observable forensic traces, attacker IPs, affected accounts, and initial containment actions..."
                  className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-slate-400 hover:text-white text-xs font-mono-code"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingForm}
                  className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase tracking-wider transition-colors shadow-md cursor-pointer"
                >
                  {submittingForm ? 'Logging Incident...' : 'Commit Incident'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIEW DETAILS & TIMELINE MODAL */}
      {detailsModalOpen && selectedIncident && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#091424] border border-cyan-500/40 rounded-2xl max-w-2xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between pb-4 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-tech text-xl font-bold text-cyan-400">
                    {selectedIncident.incidentNumber}
                  </span>
                  <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                    {selectedIncident.category}
                  </span>
                  <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-500/30">
                    {selectedIncident.severity}
                  </span>
                </div>
                <h2 className="text-base font-bold text-white mt-1">
                  {selectedIncident.title}
                </h2>
              </div>
              <button onClick={() => setDetailsModalOpen(false)} className="text-slate-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-5 text-xs font-mono-code">
              {/* Metadata Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <div>
                  <span className="text-slate-500">STATUS:</span>
                  <p className="text-cyan-300 font-bold mt-0.5">{selectedIncident.status}</p>
                </div>
                <div>
                  <span className="text-slate-500">AFFECTED SYSTEM:</span>
                  <p className="text-white mt-0.5 truncate">{selectedIncident.affectedSystem}</p>
                </div>
                <div>
                  <span className="text-slate-500">INVESTIGATOR:</span>
                  <p className="text-white mt-0.5">{selectedIncident.assignedInvestigator}</p>
                </div>
                <div>
                  <span className="text-slate-500">DISPATCHED:</span>
                  <p className="text-slate-300 mt-0.5">{new Date(selectedIncident.createdAt).toLocaleString()}</p>
                </div>
                <div>
                  <span className="text-slate-500">LAST SYNC:</span>
                  <p className="text-slate-300 mt-0.5">{new Date(selectedIncident.updatedAt).toLocaleString()}</p>
                </div>
                <div>
                  <span className="text-slate-500">EVIDENCE FILES:</span>
                  <p className="text-cyan-400 font-bold mt-0.5">{relatedEvidence.length} in Vault</p>
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="text-slate-400 uppercase tracking-wider mb-1.5 font-bold">Threat Briefing</h4>
                <p className="text-slate-200 leading-relaxed bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
                  {selectedIncident.description}
                </p>
              </div>

              {/* Related Evidence if any */}
              {relatedEvidence.length > 0 && (
                <div>
                  <h4 className="text-slate-400 uppercase tracking-wider mb-2 font-bold flex items-center gap-1.5">
                    <FileCheck2 className="w-4 h-4 text-cyan-400" />
                    Sealed Digital Evidence ({relatedEvidence.length})
                  </h4>
                  <div className="space-y-2">
                    {relatedEvidence.map(ev => (
                      <div key={ev.id} className="p-2.5 rounded-lg bg-slate-900 border border-cyan-500/20 flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-white">{ev.filename}</div>
                          <div className="text-[10px] text-slate-400 truncate max-w-sm">SHA-256: {ev.sha256Hash}</div>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                          SEALED
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Incident Timeline */}
              <div>
                <h4 className="text-slate-400 uppercase tracking-wider mb-3 font-bold flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-purple-400" />
                  Forensic Timeline & Investigator Actions
                </h4>
                <div className="relative pl-6 border-l border-cyan-500/30 space-y-4">
                  {selectedIncident.timeline?.map(tl => (
                    <div key={tl.id} className="relative group">
                      <div className="absolute -left-[31px] top-1 w-2.5 h-2.5 rounded-full bg-cyan-400 ring-4 ring-slate-900" />
                      <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800 space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-bold text-cyan-300">{tl.action}</span>
                          <span className="text-slate-500">{new Date(tl.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        {tl.note && <p className="text-slate-300 text-xs">{tl.note}</p>}
                        <div className="text-[9px] text-slate-500">By: {tl.author}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add Timeline Note Form */}
                <form onSubmit={handleAddTimelineNote} className="mt-4 pt-3 border-t border-slate-800 flex gap-2">
                  <input
                    type="text"
                    value={newTimelineNote}
                    onChange={e => setNewTimelineNote(e.target.value)}
                    placeholder="Append forensic observation or containment step..."
                    className="flex-1 px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                  <button
                    type="submit"
                    disabled={addingTimelineNote || !newTimelineNote.trim()}
                    className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase transition-colors disabled:opacity-50 flex items-center gap-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Add</span>
                  </button>
                </form>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div className="space-x-2">
                <button
                  onClick={() => {
                    setDetailsModalOpen(false);
                    openEditModal(selectedIncident);
                  }}
                  className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-mono-code"
                >
                  Edit Incident Details
                </button>
              </div>
              <button
                onClick={() => setDetailsModalOpen(false)}
                className="px-4 py-1.5 rounded bg-cyan-500 text-slate-950 font-bold text-xs font-mono-code"
              >
                Close Case Drawer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT MODAL */}
      {editModalOpen && selectedIncident && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#091424] border border-cyan-500/40 rounded-2xl max-w-xl w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
                Edit Case {selectedIncident.incidentNumber}
              </h3>
              <button onClick={() => setEditModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditIncident} className="py-4 space-y-4">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Category</label>
                  <select
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Severity</label>
                  <select
                    value={formSeverity}
                    onChange={e => setFormSeverity(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                  >
                    {severities.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Status</label>
                  <select
                    value={formStatus}
                    onChange={e => setFormStatus(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                  >
                    {statuses.map(st => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-mono-code text-slate-300 mb-1">Investigator</label>
                  <input
                    type="text"
                    value={formAssignedInvestigator}
                    onChange={e => setFormAssignedInvestigator(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={formDescription}
                  onChange={e => setFormDescription(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-mono-code"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditModalOpen(false)}
                  className="px-4 py-2 text-slate-400 hover:text-white text-xs font-mono-code"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingForm}
                  className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#1a080c] border border-red-500/50 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-red-400">
              <AlertCircle className="w-6 h-6 shrink-0" />
              <h3 className="font-tech text-lg font-bold uppercase tracking-wider text-white">
                Confirm Incident Purge
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-mono-code">
              Are you sure you want to permanently purge this incident record? This action will remove the case and its chain of custody timeline notes from the active database.
            </p>
            <div className="pt-2 flex items-center justify-end gap-3 font-mono-code">
              <button
                type="button"
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 rounded-lg text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDeleteIncident(deleteConfirmId)}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider shadow-lg"
              >
                Purge Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
