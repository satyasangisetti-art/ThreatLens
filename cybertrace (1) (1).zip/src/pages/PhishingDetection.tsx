import React, { useState } from 'react';
import {
  MailWarning,
  Globe,
  MessageSquare,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Lock,
  Unlock,
  ExternalLink,
  CheckCircle2,
  XCircle,
  Copy,
  Terminal,
  Zap,
} from 'lucide-react';
import { api } from '../lib/api';
import { ThreatAnalysis } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

export const PhishingDetection: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError, info } = useToast();

  const [inputMode, setInputMode] = useState<'url' | 'email' | 'sms'>('url');
  const [content, setContent] = useState('');
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<ThreatAnalysis | null>(null);

  // URL-specific parsed heuristics
  const [urlMetrics, setUrlMetrics] = useState<{
    protocol: string;
    domain: string;
    isIpAddress: boolean;
    isShortener: boolean;
    hasPunycode: boolean;
    subdomainDepth: number;
    impersonatedBrand: string | null;
  } | null>(null);

  const testSamples = [
    {
      title: 'Paypal Typosquat',
      type: 'url' as const,
      text: 'https://pay-pa1-security-verification.com/webapps/mpp/account-recovery',
    },
    {
      title: 'Raw IP Bank Lure',
      type: 'url' as const,
      text: 'http://198.51.100.89:8080/secure/bankofamerica/login.php?token=9841',
    },
    {
      title: 'CEO Gift Card Scam',
      type: 'email' as const,
      text: `From: Richard Anderson <ceo@exec-corp-mail.net>\nTo: accounts@company.com\nSubject: Quick favor - Urgent meeting\n\nI need you to purchase 5 x $500 Apple gift cards for a client presentation in 30 minutes. Scratch the back, take pictures and send me the PIN codes right away. Will reimburse upon return.`,
    },
    {
      title: 'Package Delivery SMS',
      type: 'sms' as const,
      text: 'USPS: Your package delivery has been stopped due to unpaid custom duty of $2.45. Reschedule immediately at https://usps-track-package-duty.org/parcel to avoid return to sender.',
    },
  ];

  const parseUrlHeuristics = (input: string) => {
    try {
      let target = input.trim();
      if (!target.startsWith('http://') && !target.startsWith('https://')) {
        target = 'https://' + target;
      }
      const parsed = new URL(target);
      const isIp = /^(\d{1,3}\.){3}\d{1,3}$/.test(parsed.hostname);
      const isShortener = ['bit.ly', 'tinyurl.com', 't.co', 'is.gd', 'rb.gy'].includes(parsed.hostname);
      const hasPunycode = parsed.hostname.startsWith('xn--') || parsed.hostname.includes('.xn--');
      const subdomains = parsed.hostname.split('.');
      const depth = subdomains.length - 2;

      let brand = null;
      const lower = parsed.hostname.toLowerCase();
      if (lower.includes('paypal') && !lower.endsWith('.paypal.com')) brand = 'PayPal';
      else if (lower.includes('microsoft') && !lower.endsWith('.microsoft.com')) brand = 'Microsoft';
      else if (lower.includes('apple') && !lower.endsWith('.apple.com')) brand = 'Apple';
      else if (lower.includes('google') && !lower.endsWith('.google.com')) brand = 'Google';
      else if (lower.includes('chase') && !lower.endsWith('.chase.com')) brand = 'Chase Bank';

      setUrlMetrics({
        protocol: parsed.protocol,
        domain: parsed.hostname,
        isIpAddress: isIp,
        isShortener,
        hasPunycode,
        subdomainDepth: Math.max(0, depth),
        impersonatedBrand: brand,
      });
    } catch {
      setUrlMetrics(null);
    }
  };

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    if (inputMode === 'url') {
      parseUrlHeuristics(content);
    } else {
      setUrlMetrics(null);
    }

    setScanning(true);
    setResult(null);

    try {
      const res = await api.analyzeThreat(content, inputMode, user?.name);
      setResult(res.result);
      success('Phishing Analysis Completed', `Evaluation: ${res.result.riskClassification} (${res.result.riskScore}% risk)`);
    } catch (err: any) {
      toastError('Phishing Engine Error', err.message);
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
              Phishing & Lure Detection
            </h1>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold uppercase">
              URL & SOCIAL VECTOR RADAR
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono-code mt-1">
            Lexical Domain Parsing • Brand Impersonation Traps • Social Engineering Detection
          </p>
        </div>

        {/* Quick Samples */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] font-mono-code text-slate-400">Try Phish Samples:</span>
          {testSamples.map((s, idx) => (
            <button
              key={idx}
              onClick={() => {
                setInputMode(s.type);
                setContent(s.text);
                info(`Loaded: ${s.title}`);
              }}
              className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 hover:border-cyan-400 text-[10px] font-mono-code transition-colors cursor-pointer"
            >
              {s.title}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Panel */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4">
            {/* Mode Tabs */}
            <div className="grid grid-cols-3 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono-code">
              <button
                type="button"
                onClick={() => setInputMode('url')}
                className={`py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  inputMode === 'url' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                URL Link
              </button>
              <button
                type="button"
                onClick={() => setInputMode('email')}
                className={`py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  inputMode === 'email' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <MailWarning className="w-3.5 h-3.5" />
                Email
              </button>
              <button
                type="button"
                onClick={() => setInputMode('sms')}
                className={`py-1.5 rounded-lg flex items-center justify-center gap-1.5 transition-all ${
                  inputMode === 'sms' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                SMS / Chat
              </button>
            </div>

            <form onSubmit={handleScan} className="space-y-4">
              <div>
                <label className="block text-xs font-mono-code text-slate-300 mb-1.5">
                  {inputMode === 'url'
                    ? 'Target URL (Domain, Link, or IP)'
                    : inputMode === 'email'
                    ? 'Email Body & Subject Line'
                    : 'SMS, WhatsApp, or Telegram Message'}
                </label>
                <textarea
                  rows={inputMode === 'url' ? 4 : 8}
                  required
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  placeholder={
                    inputMode === 'url'
                      ? 'https://suspicious-banking-login.com...'
                      : 'Paste suspect message text...'
                  }
                  className="w-full p-3 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono-code"
                />
              </div>

              <button
                type="submit"
                disabled={scanning || !content.trim()}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
              >
                {scanning ? 'Dissecting Phishing Anatomy...' : 'Scan For Phishing Signatures'}
              </button>
            </form>
          </div>

          {/* Real-time Lexical Indicators Checklist */}
          {urlMetrics && (
            <div className="p-4 rounded-xl bg-[#081220] border border-cyan-500/20 text-xs font-mono-code space-y-2.5 animate-in fade-in">
              <div className="font-bold text-white flex items-center justify-between pb-2 border-b border-slate-800">
                <span>Static Lexical Parse</span>
                <span className="text-cyan-400">{urlMetrics.domain}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px]">
                <div className="flex items-center gap-1.5">
                  {urlMetrics.protocol === 'https:' ? (
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Unlock className="w-3.5 h-3.5 text-red-400" />
                  )}
                  <span className="text-slate-300">Protocol: {urlMetrics.protocol}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {urlMetrics.isIpAddress ? (
                    <XCircle className="w-3.5 h-3.5 text-red-400" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                  )}
                  <span className="text-slate-300">Direct IP: {urlMetrics.isIpAddress ? 'YES (Risk)' : 'NO'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {urlMetrics.isShortener ? (
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                  )}
                  <span className="text-slate-300">Shortener: {urlMetrics.isShortener ? 'YES' : 'NO'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  {urlMetrics.impersonatedBrand ? (
                    <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
                  ) : (
                    <CheckCircle2 className="w-3.5 h-3.5 text-slate-400" />
                  )}
                  <span className="text-slate-300">Brand: {urlMetrics.impersonatedBrand || 'None detected'}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-7">
          {result ? (
            <div className="p-6 rounded-2xl bg-[#070e1c] border border-cyan-500/30 shadow-2xl space-y-5">
              {/* Phishing Probability Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div>
                  <span className="text-[10px] font-mono-code text-slate-400 uppercase tracking-widest">
                    Phishing Probability Assessment
                  </span>
                  <h3 className="font-tech text-2xl font-bold text-white mt-0.5">
                    {result.riskScore}% Likelihood of Phishing Attack
                  </h3>
                </div>
                <span
                  className={`px-3 py-1 rounded-lg text-xs font-mono-code font-bold border ${
                    result.riskScore >= 70
                      ? 'bg-red-950/80 text-red-300 border-red-500/50'
                      : result.riskScore >= 40
                      ? 'bg-amber-950/80 text-amber-300 border-amber-500/50'
                      : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                  }`}
                >
                  {result.riskClassification}
                </span>
              </div>

              {/* Progress meter */}
              <div>
                <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className={`h-full transition-all duration-700 ${
                      result.riskScore >= 70
                        ? 'bg-gradient-to-r from-amber-500 to-red-500'
                        : result.riskScore >= 40
                        ? 'bg-yellow-500'
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${result.riskScore}%` }}
                  />
                </div>
              </div>

              {/* Detected Indicators */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono-code text-slate-400 uppercase tracking-wider font-bold">
                  Phishing Signatures Identified
                </h4>
                <div className="space-y-2">
                  {result.indicators.map((ind, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-start gap-2.5 text-xs font-mono-code text-slate-200"
                    >
                      <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                      <div>{ind}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Explanation */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono-code text-slate-400 uppercase tracking-wider font-bold">
                  Attack Vector Analysis
                </h4>
                <p className="text-xs font-mono-code text-slate-300 leading-relaxed bg-slate-900/60 p-4 rounded-xl border border-slate-800">
                  {result.explanation}
                </p>
              </div>

              {/* Recommended Actions */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono-code text-cyan-400 uppercase tracking-wider font-bold">
                  Safety & Containment Protocol
                </h4>
                <div className="space-y-1.5 font-mono-code text-xs">
                  {result.recommendedActions.map((action, i) => (
                    <div key={i} className="flex items-start gap-2 text-slate-300 p-2 rounded bg-cyan-950/20 border border-cyan-500/10">
                      <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center p-8 rounded-2xl bg-[#070e1c] border border-dashed border-cyan-500/20 text-center space-y-3">
              <MailWarning className="w-12 h-12 text-cyan-400/60" />
              <h3 className="font-tech text-lg font-bold text-white uppercase">Phishing Radar Standing By</h3>
              <p className="text-xs text-slate-400 font-mono-code max-w-sm">
                Submit an incoming link or email to run lexical lookalike checks, brand impersonation detection, and credential theft analysis.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
