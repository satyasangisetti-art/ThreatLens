import React, { useState } from 'react';
import {
  Settings,
  User,
  Shield,
  KeyRound,
  Bell,
  Sliders,
  CheckCircle2,
  Lock,
  LogOut,
  Building,
  Mail,
  Smartphone,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';

export const SettingsPage: React.FC = () => {
  const { user, updateProfile, logout, isSupabaseMode } = useAuth();
  const { success, info } = useToast();

  const [name, setName] = useState(user?.name || '');
  const [organization, setOrganization] = useState(user?.organization || 'CyberTrace Core SOC');
  const [role, setRole] = useState(user?.role || 'SOC Analyst');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Preferences
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [criticalPush, setCriticalPush] = useState(true);
  const [dailyDigest, setDailyDigest] = useState(false);
  const [twoFactor, setTwoFactor] = useState(user?.twoFactorEnabled ?? true);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({
      name,
      organization,
      role: role as any,
      twoFactorEnabled: twoFactor,
    });
    success('Profile Synchronized', 'Analyst credentials updated in SOC registry.');
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword !== confirmPassword) {
      info('Passwords must match and meet complexity criteria.');
      return;
    }
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    success('Access Key Rotated', 'New authentication credential registered.');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-in fade-in">
      {/* Header */}
      <div className="pb-2 border-b border-slate-800">
        <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
          SOC Operator Settings
        </h1>
        <p className="text-xs text-slate-400 font-mono-code mt-1">
          Analyst Profile • Access Keys • Notification Telemetry • Defcon Settings
        </p>
      </div>

      {/* Profile Card */}
      <div className="p-6 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-5">
        <div className="flex items-center gap-4 pb-4 border-b border-slate-800">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center font-tech text-2xl font-bold text-white shadow-inner">
            {user?.name ? user.name.charAt(0).toUpperCase() : 'A'}
          </div>
          <div>
            <h3 className="font-tech text-xl font-bold text-white">
              {user?.name || 'Authorized Analyst'}
            </h3>
            <p className="text-xs text-cyan-400 font-mono-code">
              {user?.email} • {user?.role || 'SOC Analyst'}
            </p>
            <div className="flex items-center gap-2 mt-1 text-[10px] font-mono-code text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>ACTIVE SESSION • {isSupabaseMode ? 'SUPABASE RLS' : 'LOCAL PERSISTENCE'}</span>
            </div>
          </div>
        </div>

        <form onSubmit={handleSaveProfile} className="space-y-4 font-mono-code text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 mb-1">Analyst Full Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Organization Unit</label>
              <input
                type="text"
                value={organization}
                onChange={e => setOrganization(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-300 mb-1">Assigned SOC Role</label>
              <select
                value={role}
                onChange={e => setRole(e.target.value as any)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="SOC Analyst">SOC Analyst</option>
                <option value="Incident Commander">Incident Commander</option>
                <option value="Threat Hunter">Threat Hunter</option>
                <option value="Security Admin">Security Admin</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Two-Factor Authentication (2FA)</label>
              <div className="flex items-center gap-3 pt-2">
                <input
                  type="checkbox"
                  id="2fa-toggle"
                  checked={twoFactor}
                  onChange={e => setTwoFactor(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-cyan-500 w-4 h-4 cursor-pointer"
                />
                <label htmlFor="2fa-toggle" className="text-slate-300 cursor-pointer">
                  Require Hardware Key / TOTP Authenticator
                </label>
              </div>
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase cursor-pointer"
            >
              Save Profile Settings
            </button>
          </div>
        </form>
      </div>

      {/* Password Rotation Card */}
      <div className="p-6 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4 font-mono-code text-xs">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
          <KeyRound className="w-5 h-5 text-cyan-400" />
          <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
            Access Key & Password Rotation
          </h3>
        </div>

        <form onSubmit={handleUpdatePassword} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 mb-1">Current Password</label>
              <input
                type="password"
                value={currentPassword}
                onChange={e => setCurrentPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">New Access Key</label>
              <input
                type="password"
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Confirm New Key</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 font-bold text-xs uppercase cursor-pointer"
            >
              Rotate Password
            </button>
          </div>
        </form>
      </div>

      {/* Notifications Preferences */}
      <div className="p-6 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-4 font-mono-code text-xs">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
          <Bell className="w-5 h-5 text-purple-400" />
          <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
            Incident Notification Routing
          </h3>
        </div>

        <div className="space-y-3">
          <label className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-800 cursor-pointer">
            <div>
              <div className="font-semibold text-white">Critical Severity Push Triggers</div>
              <div className="text-[10px] text-slate-400">Immediate alert dispatch upon Critical score ≥ 80 incidents</div>
            </div>
            <input
              type="checkbox"
              checked={criticalPush}
              onChange={e => setCriticalPush(e.target.checked)}
              className="w-4 h-4 rounded text-cyan-500"
            />
          </label>

          <label className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-800 cursor-pointer">
            <div>
              <div className="font-semibold text-white">Encrypted Email Forensics Dispatch</div>
              <div className="text-[10px] text-slate-400">Send sealed SHA-256 evidence digests to primary email</div>
            </div>
            <input
              type="checkbox"
              checked={emailAlerts}
              onChange={e => setEmailAlerts(e.target.checked)}
              className="w-4 h-4 rounded text-cyan-500"
            />
          </label>

          <label className="flex items-center justify-between p-3 rounded-lg bg-slate-900/60 border border-slate-800 cursor-pointer">
            <div>
              <div className="font-semibold text-white">Daily SOC Incident Summary</div>
              <div className="text-[10px] text-slate-400">Receive 24-hour summary of resolved cases and mitigated lures</div>
            </div>
            <input
              type="checkbox"
              checked={dailyDigest}
              onChange={e => setDailyDigest(e.target.checked)}
              className="w-4 h-4 rounded text-cyan-500"
            />
          </label>
        </div>
      </div>

      {/* Session Termination Card */}
      <div className="p-6 rounded-2xl bg-red-950/20 border border-red-500/30 shadow-xl flex items-center justify-between font-mono-code text-xs">
        <div>
          <div className="font-bold text-red-300">Terminate Active Console Session</div>
          <div className="text-[10px] text-slate-400">Invalidate session tokens and lock console credentials</div>
        </div>
        <button
          onClick={() => logout()}
          className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase flex items-center gap-1.5 cursor-pointer shadow-lg"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
};
