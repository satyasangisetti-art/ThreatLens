import React, { useState, useEffect } from 'react';
import {
  FileText,
  Send,
  Search,
  ExternalLink,
  ShieldAlert,
  ShieldCheck,
  AlertOctagon,
  Clock,
  DollarSign,
  Download,
  CheckCircle2,
  AlertTriangle,
  X,
  FileCheck2,
} from 'lucide-react';
import { api } from '../lib/api';
import { CybercrimeReport } from '../types';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { downloadCybercrimeReportPDF } from '../utils/generateReportPdf';

export const CybercrimeReports: React.FC = () => {
  const { user } = useAuth();
  const { success, error: toastError, info } = useToast();

  const [reports, setReports] = useState<CybercrimeReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'submit' | 'history' | 'track'>('submit');

  // Form fields
  const [complainantName, setComplainantName] = useState(user?.name || '');
  const [contactEmail, setContactEmail] = useState(user?.email || '');
  const [phoneNumber, setPhoneNumber] = useState('+1 (555) 234-5678');
  const [fraudCategory, setFraudCategory] = useState('Executive Email Compromise (BEC)');
  const [financialLossAmount, setFinancialLossAmount] = useState('12500');
  const [currency, setCurrency] = useState('USD');
  const [transactionId, setTransactionId] = useState('WIRE-TX-98402-CHASE');
  const [suspiciousUrl, setSuspiciousUrl] = useState('https://secure-invoice-verify.com');
  const [suspectContact, setSuspectContact] = useState('spoofed-accounting@vendor-fake.com');
  const [description, setDescription] = useState(
    'Victim company was contacted by spoofed email requesting urgent rerouting of pending invoice settlement to offshore account.'
  );
  const [submitting, setSubmitting] = useState(false);

  // Tracking field
  const [searchRef, setSearchRef] = useState('');
  const [trackedReport, setTrackedReport] = useState<CybercrimeReport | null>(null);
  const [selectedReportForSummary, setSelectedReportForSummary] = useState<CybercrimeReport | null>(null);

  const fraudCategories = [
    'Executive Email Compromise (BEC)',
    'Cryptocurrency Impersonation & Investment Scam',
    'Ransomware & Extortion',
    'Identity Theft & Account Takeover',
    'Online Banking / Wire Transfer Fraud',
    'Social Engineering / Romance Scam',
    'Phishing & Credential Theft',
    'Tech Support Impersonation',
    'Other Cybercrime Incident',
  ];

  const loadReports = async () => {
    try {
      setLoading(true);
      const res = await api.getReports();
      setReports(res.reports || []);
    } catch (err: any) {
      toastError('Failed to load reports', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!complainantName || !contactEmail || !description) return;

    setSubmitting(true);
    try {
      const res = await api.submitReport({
        complainantName,
        contactEmail,
        phoneNumber,
        fraudCategory,
        financialLossAmount: Number(financialLossAmount) || 0,
        currency,
        transactionId,
        suspiciousUrl,
        suspectContact,
        description,
        evidenceFiles: ['attached_wire_instructions.pdf'],
      });

      success('Complaint Logged', `Case Reference ID: ${res.report.referenceNumber}`);
      setSelectedReportForSummary(res.report);
      loadReports();
    } catch (err: any) {
      toastError('Submission Error', err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchRef.trim()) return;

    try {
      const res = await api.getReportById(searchRef.trim());
      setTrackedReport(res.report);
      success('Complaint Located', `Status: ${res.report.status}`);
    } catch (err: any) {
      toastError('Report Not Found', 'No complaint found matching this Reference ID.');
      setTrackedReport(null);
    }
  };

  const handleDownloadPdf = (report: CybercrimeReport) => {
    try {
      downloadCybercrimeReportPDF(report);
      success('PDF Dossier Generated', `Official report ${report.referenceNumber}.pdf downloaded.`);
    } catch (err: any) {
      toastError('PDF Generation Error', err?.message || 'Could not compile PDF document.');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-tech text-2xl sm:text-3xl font-bold text-white uppercase tracking-wider">
              Cybercrime Reporting Portal
            </h1>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 font-bold uppercase">
              FRAUD INTAKE
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono-code mt-1">
            Structured Incident Reporting • Chain-of-Evidence Formatting • Law Enforcement Hand-off
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono-code">
          <button
            onClick={() => setActiveTab('submit')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'submit' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            File Complaint
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'history' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Complaint History ({reports.length})
          </button>
          <button
            onClick={() => setActiveTab('track')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'track' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Track Reference
          </button>
        </div>
      </div>

      {/* Official Legal Disclaimer Banner */}
      <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 flex items-start gap-3 text-xs font-mono-code text-amber-200">
        <AlertOctagon className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-white uppercase">Official Reporting Disclaimer</div>
          <p className="text-amber-200/90 leading-relaxed text-[11px]">
            CYBERTRACE is an enterprise threat intelligence and evidence preservation platform. We assist organizations and individuals with technical documentation and forensic intake. For official law enforcement investigations, filings must also be submitted to your relevant statutory body:
          </p>
          <div className="flex flex-wrap gap-4 pt-1 text-[11px]">
            <a
              href="https://www.ic3.gov"
              target="_blank"
              rel="noreferrer"
              className="text-cyan-300 hover:underline flex items-center gap-1"
            >
              Federal FBI IC3 (US) <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href="https://cybercrime.gov.in"
              target="_blank"
              rel="noreferrer"
              className="text-cyan-300 hover:underline flex items-center gap-1"
            >
              National Cyber Crime Portal (India - 1930) <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href="https://www.europol.europa.eu/about-europol/european-cybercrime-centre-ec3"
              target="_blank"
              rel="noreferrer"
              className="text-cyan-300 hover:underline flex items-center gap-1"
            >
              Europol EC3 (EU) <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>

      {/* TAB: SUBMIT COMPLAINT */}
      {activeTab === 'submit' && (
        <form onSubmit={handleSubmit} className="p-6 rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl space-y-6 font-mono-code text-xs">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
              1. Complainant Identification
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 mb-1">Complainant / Entity Name</label>
              <input
                type="text"
                required
                value={complainantName}
                onChange={e => setComplainantName(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Contact Email</label>
              <input
                type="email"
                required
                value={contactEmail}
                onChange={e => setContactEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Phone Number</label>
              <input
                type="text"
                value={phoneNumber}
                onChange={e => setPhoneNumber(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div className="border-b border-slate-800 pb-3 pt-2">
            <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
              2. Fraud Classification & Financial Loss
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 mb-1">Fraud Category</label>
              <select
                value={fraudCategory}
                onChange={e => setFraudCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              >
                {fraudCategories.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Financial Loss Amount</label>
              <input
                type="number"
                value={financialLossAmount}
                onChange={e => setFinancialLossAmount(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Currency</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="INR">INR (₹)</option>
                <option value="USDT">USDT / Crypto</option>
              </select>
            </div>
          </div>

          <div className="border-b border-slate-800 pb-3 pt-2">
            <h3 className="font-tech text-lg font-bold text-white uppercase tracking-wider">
              3. Suspect & Transaction Telemetry
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-slate-300 mb-1">Transaction ID / TX Hash</label>
              <input
                type="text"
                value={transactionId}
                onChange={e => setTransactionId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Suspect Phone / Contact / Email</label>
              <input
                type="text"
                value={suspectContact}
                onChange={e => setSuspectContact(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div>
              <label className="block text-slate-300 mb-1">Suspicious Link / Domain</label>
              <input
                type="text"
                value={suspiciousUrl}
                onChange={e => setSuspiciousUrl(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-300 mb-1">Detailed Description of Cybercrime Scheme</label>
            <textarea
              rows={4}
              required
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Chronological summary of contact, communication medium, financial transactions, and impact..."
              className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-cyan-400 leading-relaxed"
            />
          </div>

          <div className="pt-4 border-t border-slate-800 flex items-center justify-end">
            <button
              type="submit"
              disabled={submitting}
              className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] disabled:opacity-50 cursor-pointer flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              {submitting ? 'Encrypting & Generating Reference...' : 'Submit Cybercrime Complaint'}
            </button>
          </div>
        </form>
      )}

      {/* TAB: COMPLAINT HISTORY */}
      {activeTab === 'history' && (
        <div className="rounded-2xl bg-[#070e1c] border border-cyan-500/20 shadow-xl overflow-hidden font-mono-code text-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-[#0b162c] text-slate-400 border-b border-cyan-500/20">
                <tr>
                  <th className="py-3 px-4">REFERENCE ID</th>
                  <th className="py-3 px-4">COMPLAINANT</th>
                  <th className="py-3 px-4">FRAUD CATEGORY</th>
                  <th className="py-3 px-4">FINANCIAL LOSS</th>
                  <th className="py-3 px-4">STATUS</th>
                  <th className="py-3 px-4">SUBMITTED</th>
                  <th className="py-3 px-4 text-right">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {reports.map(rep => (
                  <tr key={rep.id} className="hover:bg-cyan-950/15 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-cyan-400">
                      {rep.referenceNumber}
                    </td>
                    <td className="py-3.5 px-4 text-white font-semibold">
                      {rep.complainantName}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300">
                      {rep.fraudCategory}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-amber-400">
                      {rep.currency} {rep.financialLossAmount.toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-900 border border-cyan-500/30 text-cyan-300">
                        {rep.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-400">
                      {new Date(rep.submittedAt).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleDownloadPdf(rep)}
                        title="Download Official PDF Dossier"
                        className="px-2.5 py-1 rounded bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 text-[10px] inline-flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        <Download className="w-3 h-3" />
                        <span>PDF</span>
                      </button>
                      <button
                        onClick={() => setSelectedReportForSummary(rep)}
                        className="px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-[10px] transition-colors"
                      >
                        Summary
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: TRACK REFERENCE */}
      {activeTab === 'track' && (
        <div className="max-w-2xl mx-auto space-y-6">
          <form onSubmit={handleTrack} className="p-6 rounded-2xl bg-[#070e1c] border border-cyan-500/20 space-y-4">
            <h3 className="font-tech text-lg font-bold text-white uppercase">
              Track Complaint Dossier
            </h3>
            <p className="text-xs text-slate-400 font-mono-code">
              Enter your official Reference ID (e.g. CT-CR-2026-0491) to view status updates and forensic triage stage.
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                required
                value={searchRef}
                onChange={e => setSearchRef(e.target.value)}
                placeholder="CT-CR-2026-0491"
                className="flex-1 px-4 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-white font-mono-code focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs uppercase font-mono-code cursor-pointer"
              >
                Track Status
              </button>
            </div>
          </form>

          {trackedReport && (
            <div className="p-6 rounded-2xl bg-[#081220] border border-cyan-500/40 font-mono-code text-xs space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="font-tech text-xl font-bold text-cyan-400">
                  {trackedReport.referenceNumber}
                </span>
                <span className="px-2.5 py-1 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-bold">
                  {trackedReport.status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-slate-300">
                <div>Complainant: <strong className="text-white">{trackedReport.complainantName}</strong></div>
                <div>Category: <strong className="text-white">{trackedReport.fraudCategory}</strong></div>
                <div>Loss Amount: <strong className="text-amber-400">{trackedReport.currency} {trackedReport.financialLossAmount.toLocaleString()}</strong></div>
                <div>Dispatched: <strong className="text-white">{new Date(trackedReport.submittedAt).toLocaleString()}</strong></div>
              </div>
              <p className="p-3 rounded-lg bg-slate-900 text-slate-300 leading-relaxed border border-slate-800">
                {trackedReport.description}
              </p>
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={() => handleDownloadPdf(trackedReport)}
                  className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase flex items-center gap-2 cursor-pointer shadow-[0_0_15px_rgba(6,182,212,0.3)]"
                >
                  <Download className="w-4 h-4" />
                  <span>Download PDF Dossier</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUMMARY MODAL */}
      {selectedReportForSummary && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#091424] border border-cyan-500/40 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative font-mono-code text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-tech text-lg font-bold text-white uppercase">
                  Complaint Dossier Summary
                </h3>
              </div>
              <button onClick={() => setSelectedReportForSummary(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-3">
              <div className="p-3 rounded-lg bg-slate-900 border border-cyan-500/30 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400">REFERENCE NUMBER</span>
                  <div className="font-tech text-xl font-bold text-cyan-400">
                    {selectedReportForSummary.referenceNumber}
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 text-[10px]">
                  {selectedReportForSummary.status}
                </span>
              </div>

              <div className="space-y-1.5 text-slate-300 text-xs">
                <div><strong>Complainant:</strong> {selectedReportForSummary.complainantName} ({selectedReportForSummary.contactEmail})</div>
                <div><strong>Category:</strong> {selectedReportForSummary.fraudCategory}</div>
                <div><strong>Loss Amount:</strong> {selectedReportForSummary.currency} {selectedReportForSummary.financialLossAmount.toLocaleString()}</div>
                <div><strong>Transaction ID:</strong> {selectedReportForSummary.transactionId}</div>
                <div><strong>Suspect Telemetry:</strong> {selectedReportForSummary.suspectContact}</div>
                <div><strong>Suspicious URL:</strong> {selectedReportForSummary.suspiciousUrl}</div>
              </div>

              <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-[11px] leading-relaxed">
                {selectedReportForSummary.description}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => handleDownloadPdf(selectedReportForSummary)}
                className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs uppercase flex items-center gap-1.5 shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Official PDF Dossier</span>
              </button>
              <button
                type="button"
                onClick={() => setSelectedReportForSummary(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
