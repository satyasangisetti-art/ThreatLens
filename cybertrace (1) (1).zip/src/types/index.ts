export interface User {
  id: string;
  email: string;
  name: string;
  role: 'SOC Analyst' | 'Incident Commander' | 'Threat Hunter' | 'Security Admin';
  avatarUrl?: string;
  organization: string;
  twoFactorEnabled: boolean;
  createdAt: string;
}

export interface Incident {
  id: string;
  incidentNumber: string;
  title: string;
  category: 'Phishing' | 'Malware' | 'Ransomware' | 'Data Breach' | 'Unauthorized Access' | 'DDoS Attack' | 'Financial Fraud' | 'Identity Theft' | 'Social Engineering' | 'Other';
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Open' | 'Investigating' | 'Contained' | 'Resolved';
  description: string;
  affectedSystem: string;
  assignedInvestigator: string;
  timeline: Array<{
    id: string;
    timestamp: string;
    author: string;
    action: string;
    note?: string;
  }>;
  evidenceCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface ThreatAnalysis {
  id: string;
  inputContent: string;
  inputType: 'url' | 'email' | 'sms' | 'text' | 'image';
  riskScore: number;
  riskClassification: 'Safe' | 'Suspicious' | 'High Risk' | 'Critical';
  threatCategory: string;
  confidenceScore: number;
  indicators: string[];
  explanation: string;
  recommendedActions: string[];
  analyzedAt: string;
  analyzedBy: string;
  engine: string;
  isSimulatedFallback?: boolean;
}


export interface EvidenceFile {
  id: string;
  incidentId?: string;
  filename: string;
  fileSize: number;
  fileType: string;
  sha256Hash: string;
  uploadedBy: string;
  uploadedAt: string;
  notes: string;
  integrityVerified: boolean;
  lastVerifiedAt: string;
  dataUrl?: string;
}

export interface CybercrimeReport {
  id: string;
  referenceNumber: string;
  complainantName: string;
  contactEmail: string;
  phoneNumber: string;
  fraudCategory: string;
  financialLossAmount: number;
  currency: string;
  transactionId: string;
  suspiciousUrl: string;
  suspectContact: string;
  description: string;
  status: 'Received' | 'Triaged' | 'Evidence Collected' | 'Forwarded to Authorities' | 'Resolved';
  submittedAt: string;
  updatedAt: string;
  evidenceFiles: string[];
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  user: string;
  action: 'LOGIN' | 'LOGOUT' | 'INCIDENT_CREATED' | 'INCIDENT_UPDATED' | 'EVIDENCE_UPLOADED' | 'THREAT_ANALYZED' | 'REPORT_FILED' | 'SYSTEM_ALERT';
  details: string;
  ipAddress: string;
  severity: 'info' | 'warning' | 'alert' | 'success';
}

export interface DashboardMetrics {
  totalIncidents: number;
  activeThreats: number;
  resolvedIncidents: number;
  criticalAlerts: number;
  suspiciousUrlsAnalyzed: number;
  totalEvidenceStored: number;
  socHealthScore: number;
}
