import {
  Incident,
  ThreatAnalysis,
  EvidenceFile,
  CybercrimeReport,
  ActivityLog,
  DashboardMetrics,
  User,
} from '../types';

const BASE_URL = '';

async function fetchJSON<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers || {}),
    },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || `Request failed with status ${res.status}`);
  }

  return res.json();
}

export const api = {
  // Auth
  async login(email: string, password?: string): Promise<{ user: User; session: { token: string } }> {
    return fetchJSON('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  async register(data: { email: string; name: string; organization?: string; role?: string }): Promise<{ user: User; session: { token: string } }> {
    return fetchJSON('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async getMe(): Promise<{ user: User }> {
    return fetchJSON('/api/auth/me');
  },

  async logout(): Promise<void> {
    await fetchJSON('/api/auth/logout', { method: 'POST' });
  },

  // Stats
  async getDashboardStats(): Promise<{
    metrics: DashboardMetrics;
    severityDistribution: Array<{ name: string; value: number; color: string }>;
    categoryBreakdown: Array<{ category: string; count: number }>;
    trendData: Array<{ day: string; incidents: number; blockedThreats: number; resolved: number }>;
    recentIncidents: Incident[];
    recentActivity: ActivityLog[];
  }> {
    return fetchJSON('/api/stats');
  },

  // Incidents
  async getIncidents(params?: { category?: string; severity?: string; status?: string; search?: string }): Promise<{ incidents: Incident[]; count: number }> {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.set('category', params.category);
    if (params?.severity) searchParams.set('severity', params.severity);
    if (params?.status) searchParams.set('status', params.status);
    if (params?.search) searchParams.set('search', params.search);

    const query = searchParams.toString() ? `?${searchParams.toString()}` : '';
    return fetchJSON(`/api/incidents${query}`);
  },

  async getIncidentById(id: string): Promise<{ incident: Incident; relatedEvidence: EvidenceFile[] }> {
    return fetchJSON(`/api/incidents/${id}`);
  },

  async createIncident(data: Partial<Incident>): Promise<{ incident: Incident }> {
    return fetchJSON('/api/incidents', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async updateIncident(id: string, data: Partial<Incident> & { newTimelineNote?: string }): Promise<{ incident: Incident }> {
    return fetchJSON(`/api/incidents/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  async deleteIncident(id: string): Promise<{ success: boolean; removedId: string }> {
    return fetchJSON(`/api/incidents/${id}`, {
      method: 'DELETE',
    });
  },

  // AI Threat Analyzer
  async analyzeThreat(content: string, type: 'url' | 'email' | 'sms' | 'text' = 'text', user?: string): Promise<{ result: ThreatAnalysis }> {
    return fetchJSON('/api/analyze-threat', {
      method: 'POST',
      body: JSON.stringify({ content, type, user }),
    });
  },

  // Evidence Vault
  async getEvidence(incidentId?: string): Promise<{ evidence: EvidenceFile[]; count: number }> {
    const query = incidentId ? `?incidentId=${encodeURIComponent(incidentId)}` : '';
    return fetchJSON(`/api/evidence${query}`);
  },

  async uploadEvidence(data: {
    filename: string;
    fileBase64?: string;
    fileSize?: number;
    fileType?: string;
    incidentId?: string;
    notes?: string;
    uploadedBy?: string;
  }): Promise<{ evidence: EvidenceFile }> {
    return fetchJSON('/api/evidence', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  async verifyEvidence(id: string): Promise<{
    verified: boolean;
    evidenceId: string;
    sha256Hash: string;
    verifiedAt: string;
    status: string;
    message: string;
  }> {
    return fetchJSON(`/api/evidence/${id}/verify`, {
      method: 'POST',
    });
  },

  async deleteEvidence(id: string): Promise<{ success: boolean; removedId: string }> {
    return fetchJSON(`/api/evidence/${id}`, {
      method: 'DELETE',
    });
  },

  // Cybercrime Reports
  async getReports(): Promise<{ reports: CybercrimeReport[]; count: number }> {
    return fetchJSON('/api/reports');
  },

  async getReportById(id: string): Promise<{ report: CybercrimeReport }> {
    return fetchJSON(`/api/reports/${id}`);
  },

  async submitReport(data: Partial<CybercrimeReport>): Promise<{ report: CybercrimeReport }> {
    return fetchJSON('/api/reports', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Activity Logs
  async getActivityLogs(): Promise<{ logs: ActivityLog[]; count: number }> {
    return fetchJSON('/api/activity-logs');
  },
};
